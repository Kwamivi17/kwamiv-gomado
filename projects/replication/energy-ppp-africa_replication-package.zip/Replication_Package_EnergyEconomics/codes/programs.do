

*==============================================================================*
* ENERGY MARKETS REFORMS AND RENEWABLE ENERGY IN AFRICA
* Do Public-Private Partnerships Matter?
*==============================================================================*


// Software: Stata/MP 19.5 (64-bit); may not work with older versions.

*===============================================================================
* PACKAGE INSTALLATION
*===============================================================================

** Install necessary packages if needed

local packages "xtscc estout asdoc schemepack ebalance grc1leg sutex ivreg2 blindschemes coefplot"
foreach pkg in `packages' {
    capture ssc install `pkg', replace
}
net install grc1leg,from( http://www.stata.com/users/vwiggins/) replace
net install schemepack, from("https://raw.githubusercontent.com/asjadnaqvi/stata-schemepack/main/installation/") replace
di "Installation completed"


*** ===========================================================================*
*** SECTION 1: SETUP AND INITIALIZATION
*** ===========================================================================*
cls
clear all
set matsize 11000, permanently
set mem 1000m
set more off

** Define project directories
global homedir "/Users/kwamivigomado/Library/CloudStorage/GoogleDrive-kwamivigomado@gmail.com/Mon Drive/Projet Energy economics/Review Replication/Replication_Package_EnergyEconomics" /* NOTE: Modify paths before replication */
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

** Display setup summary
di "Data location: $datasets"
di "Results location: $tables and $figures"
di "=========================================================="

*** ===========================================================================*
*** SECTION 2: DATA LOADING AND PANEL STRUCTURE
*** ===========================================================================*

use "$datasets/MAIN", clear

** Set up panel structure
xtset cid year
sort cid year

*** ===========================================================================*
*** SECTION 3: DEFINE KEY VARIABLES
*** ===========================================================================*

** Dependent variables
global yvar1 "logrenew_elec_share"
global yvar2 "logwdi_enerenew"

** Control variables 
global covar "lpwt_hci lwdi_trade linflation_imf lwdi_fdiin lwdi_agedr lIMF55 lany_election lFD ltotal_natural_resources_rents lwdi_gdpgr lyrcurnt llogwdi_pop licrg_qog"

** Treatment variable (energy market reform indicator)
global shock1 "ftreat_prdm_elec"

** Variable labels for output
local mylabel1 : variable label $yvar1
local mylabel2 : variable label $yvar2
local mylabel3 : variable label $shock1

di "Dependent variables defined:"
di "  - DV1: `yvar1' (`mylabel1')"
di "  - DV2: `yvar2' (`mylabel2')"
di "Treatment: $shock1"

**#4. SECTION 4: DESCRIPTIVES STATISTICS


*** ===========================================================================*
*** EVOLUTION OF SUB-INDICES: Figure 1
*** ===========================================================================*

preserve
collapse (mean) prdm_elec_ws prdm_elec_unb prdm_elec_reg prdm_elec_own, by(year)

** Create overall maximum index
egen prdm_all = rmax(prdm_elec_ws prdm_elec_unb prdm_elec_reg prdm_elec_own)

** Product market reform sub-indices
label var prdm_elec_ws  "Electricity - Wholesale"
label var prdm_elec_unb "Electricity - Unbundling"
label var prdm_elec_reg "Electricity - Regulation"
label var prdm_elec_own "Electricity - Ownership"

** Stacked bar chart with overall trend line
twoway ///
    (bar prdm_elec_ws year, barwidth(1) ///
        legend(label(1 "Wholesale") size(vsmall))) || ///
    (rbar prdm_elec_ws prdm_elec_reg year, barwidth(1) ///
        legend(label(2 "Regulation") size(vsmall))) || ///
    (rbar prdm_elec_reg prdm_elec_own year, barwidth(1) ///
        legend(label(3 "Ownership") size(vsmall))) || ///
    (rbar prdm_elec_own prdm_elec_unb year, barwidth(1) ///
        legend(label(4 "Unbundling") size(vsmall))) || ///
    (line prdm_all year, lcolor(blue) lwidth(thick) ///
        legend(label(5 "Overall liberalization index") size(vsmall))) ///
    , ///
    legend(cols(3) pos(6)) ///
    ytitle("Electricity market liberalization index") ///
    ylab(, nogrid) ///
    title("", size(small)) ///
    xlab(, nogrid angle(45)) xlabel(1990(2)2014) ///
    graphregion(color(white)) plotregion(color(white))

graph rename a, replace
graph export "$figures/figure1.pdf", replace
graph export "$figures/figure1.png", replace

restore


*===============================================================================
* AVERAGE ELECTRICITY MARKET LIBERALIZATION INDEX BY COUNTRY : Figure 2
*===============================================================================
** Figure 2
preserve
collapse (mean) prdm_elec, by(country)

graph bar (mean) prdm_elec, ///
    over(country, sort(prdm_elec) descending lab(angle(45))) ///
    bargap(-30) ///
    legend(off) ///
    ylab(0(0.1)0.4, nogrid) ///
    ytitle("Average electricity market liberalization index") ///
    graphregion(color(white)) plotregion(color(white))

graph rename figure2, replace
graph export "$figures/figure2.pdf", replace
graph export "$figures/figure2.png", replace

restore

*===============================================================================
* PPP AND REFORM EPISODES : Figure 3
*===============================================================================

** Panel A: By year
preserve

graph bar (sum) ppp_energy ftreat_prdm_elec, ///
    over(year, lab(angle(90))) ///
    bargap(-30) ///
    legend(order(1 "PPP projects" 2 "Reform episodes") ///
           span pos(6) rows(1) size(small)) ///
    ylab(0(5)40, nogrid) ///
    subtitle("Panel A) By year", size(medium)) ///
    ytitle("Number") ///
    graphregion(color(white)) plotregion(color(white))

graph rename panel_a, replace
*graph export "$figures/figure3a.pdf", replace

restore

** Panel B: By country
preserve

graph bar (sum) ppp_energy ftreat_prdm_elec, ///
    over(country, sort(ppp_energy) descending lab(angle(45))) ///
    bargap(-30) ///
    legend(order(1 "PPP projects" 2 "Reform episodes") ///
           span pos(6) rows(1) size(small)) ///
    ylab(0(5)55, nogrid) ///
    subtitle("Panel B) By country", size(medium)) ///
    ytitle("Number") ///
    graphregion(color(white)) plotregion(color(white))

graph rename panel_b, replace
*graph export "$figures/figure3b.pdf", replace

restore

** Combine both panels
grc1leg panel_a panel_b, ///
    cols(2) ///
    title("", ///
          justification(center) color(black) size(medium)) ///
    graphregion(color(white)) plotregion(color(white)) ///
    legendfrom(panel_a)

graph rename figure3, replace
graph export "$figures/figure3.pdf", replace
graph export "$figures/figure3.png", replace

***============================================================================*
***    Summary Statistics — Table A1 (LaTeX code to be copied from Stata output)
***============================================================================*

preserve

tempfile texout
log using "$tables/tableA1.tex", text replace

sutex $yvar1 $yvar2 pwt_hci wdi_trade inflation_imf wdi_fdiin ///
      wdi_agedr IMF55 any_election FD total_natural_resources_rents ///
      wdi_gdpgr yrcurnt logwdi_pop icrg_qog, minmax labels digits(3)

log close

restore


***============================================================================*
*** Table A2. Multicollinearity Test (similar results; only $yvar2 reported)
***============================================================================*

preserve
** Multicollinearity test: table A2 
ssc install asdoc
reg logrenew_elec_share $covar
asdoc vif, save($tables/tableA2.doc) replace

reg logwdi_enerenew $covar
asdoc vif, save($tables/tableA2.doc) append

restore






*** ===========================================================================*
*** SECTION 5: CREATE OUTCOME VARIABLES FOR MULTIPLE TIME HORIZONS
*** ===========================================================================*

di "Creating outcome changes at different time horizons (0-5 years ahead)..."

foreach v in $yvar1 $yvar2 {
	xtset cid year
	sort cid year
	forvalues i = 0/4 {
		cap drop `v'`i'
		gen `v'`i' = (f`i'.`v' - l.`v')
		label var `v'`i' "Year +`i' change"
	}
}

** Create sum all horizons
cap drop logrenew_elec_share5
egen logrenew_elec_share5 = rsum(logrenew_elec_share0 logrenew_elec_share1 logrenew_elec_share2 logrenew_elec_share3 logrenew_elec_share4)
label var logrenew_elec_share5 "Sum"

cap drop logwdi_enerenew5
egen logwdi_enerenew5 = rsum(logwdi_enerenew0 logwdi_enerenew1 logwdi_enerenew2 logwdi_enerenew3 logwdi_enerenew4)
label var logwdi_enerenew5 "Sum"

di "Outcome variables created for horizons: 0, 1, 2, 3, 4, and sum"



*** ===========================================================================*
*** SECTION 6: LOCAL PROJECTIONS WITH OLS (LP-OLS)
*** ===========================================================================*

di ""
di "=========================================================="
di "SECTION 6: LOCAL PROJECTIONS - OLS ESTIMATION"
di "=========================================================="
**# 6.1 Unconditional Impacts of Electricity Market Reform: Local Projection Results
**##- LP-OLS for Renewable Energy Production
di "Estimating LP-OLS for renewable energy production..."



***============================================================================*
*** Table 2. : Renewable production
***============================================================================*

preserve
estimates clear
qui foreach v in $shock1 {
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	local mylabel : variable label `v'
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	
	** Estimate model for each horizon h
	qui forv h = 0/5 {
		eststo `v'`h': xtscc `yvar1'`h' `v' $covar l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').`v' `yvar1'_cycle i.year i.cid, ase
		
		** Store coefficients and confidence intervals
		replace b = _b[`v'] if _n == `h'+2
		replace u = _b[`v'] + 1.96*_se[`v'] if _n == `h'+2
		replace d = _b[`v'] - 1.96*_se[`v'] if _n == `h'+2
		replace u10 = _b[`v'] + 1.64*_se[`v'] if _n == `h'+2
		replace d10 = _b[`v'] - 1.64*_se[`v'] if _n == `h'+2
	}
	
	** Create impulse response plot
	twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(green) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel A: `mylabel1'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	
	gr rename g1, replace
	*graph export "$figures/lpc_production.pdf", replace
}
** Export results
//Latex code - different for each panel
local preheadA  "\begin{tabular}{l*{@M}{c}} \hline" //only need in first panel
local postheadA "\hline \multicolumn{@span}{l}{\textbf{Panel A: `mylabel1'}} \\"
local postheadB "\hline \multicolumn{@span}{l}{\textbf{Panel B: `mylabel2'}} \\"
local postfootC "\hline \end{tabular}"


cap erase "$tables/table2.csv"
cap erase "$tables/table2.tex"
esttab $shock1*, append se keep($shock1) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square"))

esttab $shock1* using "$tables/table2.csv", replace se nodepvars nonotes ///
	se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep($shock1) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab $shock1* using "$tables/table2.tex", replace se nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") booktabs fragment varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep($shock1) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum") ///
	prehead(`preheadA') posthead(`postheadA')

restore





***============================================================================*
*** Table 2. : Renewable consumption
***============================================================================*

**##-LP-OLS for Renewable Energy Consumption
di "Estimating LP-OLS for renewable energy consumption..."

preserve
estimates clear
qui foreach v in $shock1 {
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	local mylabel : variable label `v'
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	
	qui forv h = 0/5 {
		eststo `v'`h': xtscc `yvar2'`h' `v' $covar l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').`v' `yvar2'_cycle i.year i.cid, ase
		
		replace b = _b[`v'] if _n == `h'+2
		replace u = _b[`v'] + 1.96*_se[`v'] if _n == `h'+2
		replace d = _b[`v'] - 1.96*_se[`v'] if _n == `h'+2
		replace u10 = _b[`v'] + 1.64*_se[`v'] if _n == `h'+2
		replace d10 = _b[`v'] - 1.64*_se[`v'] if _n == `h'+2
	}
	
	twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel B: `mylabel2'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	
	gr rename g2, replace
	*graph export "$figures/lpc_consumption.pdf", replace
}

** Export results
esttab $shock1*, append se keep($shock1) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label  varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab $shock1* using "$tables/table2.csv", append se nodepvars nonotes ///
	se(3) b(3) sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep($shock1) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab $shock1* using "$tables/table2.tex", append se nodepvars nonotes se(3) b(3) fragment booktabs ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep($shock1) nonumber nomtitle ///
                posthead(`postheadB') postfoot(`postfootC')
restore
** Combine both plots
gr combine g1 g2, cols(2) graphregion(fcolor(white)) note("")
gr rename g3, replace
graph export "$figures/figureA1.pdf", replace
graph export "$figures/figureA1.png", replace

di "LP-OLS analysis completed and saved"





***============================================================================*
*** Table A3 and Figure 4 : 
***============================================================================*

**# 6.2 Quasi-Experimental Results Using Local Projection with AIPW
**## - Propensity scores and ROC curves


preserve
di "Computing propensity scores and ROC curves..."
cap erase "$tables/tableA3.csv"
cap erase "$tables/tableA3.tex"

** For outcome variable 1
capture drop phatm
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui logit $shock1 $covar `yvar1'_cycle i.cid i.year L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4
qui predict phatm
margins, dydx(*) post
estimates store marg1

esttab marg1 using "$tables/tableA3.csv", replace drop(*cid* *year*) se nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01)
esttab marg1 using "$tables/tableA3.tex", replace drop(*cid* *year*) se nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01)

roctab $shock1 phatm
local auc = r(area)
local se = r(se)

roctab $shock1 phatm, graph legend(on ring(0) col(2) pos(6) lpattern(dash)) ///
	mlcolor(red) msize(tiny) ylab(, nogrid) xlab(, nogrid) ///
	graphregion(fcolor(white)) title("Panel A) `mylabel1'", size(2)) scheme(s1color)
gr rename g1, replace

** For outcome variable 2
capture drop phatm
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui logit $shock1 $covar `yvar2'_cycle L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4 i.cid i.year
qui predict phatm
margins, dydx(*) post
estimates store marg2
esttab marg1 marg2 using "$tables/tableA3.csv", replace drop(*cid* *year*) se nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label booktabs ///
    substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01)
esttab marg1 marg2 using "$tables/tableA3.tex", replace drop(*cid* *year*) se nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label booktabs ///
    substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01)

roctab $shock1 phatm

roctab $shock1 phatm, graph legend(on ring(0) col(2) pos(6) lpattern(dash)) ///
	mlcolor(red) msize(tiny) ylab(, nogrid) xlab(, nogrid) ///
	graphregion(fcolor(white)) title("Panel C) `mylabel2'", size(2)) scheme(s1color)
gr rename g2, replace

** 7.2 Covariate Balance: Propensity Score Distribution
di "Checking covariate balance..."

cap drop _pscore
qui logit $shock1 $covar `yvar1'_cycle L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4 i.cid i.year
predict _pscore

twoway (kdensity _pscore if $shock1==1, lpattern(dash) color(red) lwidth(medthick)) ///
	(kdensity _pscore if $shock1==0, color(blue) lwidth(thick)), ///
	text(2.9 .16 "Control units", placement(e) color(blue) size(0)) ///
	text(1.9 .58 "Treated units", placement(e) color(red) size(0)) ///
	title("Panel B) `mylabel1'", size(2)) ///
	legend(label(1 "Treated units") label(2 "Control units") col(2) pos(6)) ///
	ylabel(, labsize(small) nogrid) xlabel(, labsize(small) nogrid) ///
	ytitle("Frequency") xtitle("Estimated probability of treatment") ///
	plotregion(lpattern(blank)) scheme(s1color) legend(on)
gr rename g3, replace

cap drop _pscore
qui logit $shock1 $covar `yvar2'_cycle L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4 i.cid i.year
predict _pscore

twoway (kdensity _pscore if $shock1==1, lpattern(dash) color(red) lwidth(medthick)) ///
	(kdensity _pscore if $shock1==0, color(blue) lwidth(thick)), ///
	text(2.9 .16 "Control units", placement(e) color(blue) size(0)) ///
	text(1.9 .58 "Treated units", placement(e) color(red) size(0)) ///
	title("Panel D) `mylabel2'", size(2)) ///
	legend(label(1 "Treated units") label(2 "Control units") col(2) pos(6)) ///
	ylabel(, labsize(small) nogrid) xlabel(, labsize(small) nogrid) ///
	ytitle("Frequency") xtitle("Estimated probability of treatment") ///
	plotregion(lpattern(blank)) scheme(s1color) legend(on)
gr rename g4, replace

** Combine diagnostics
gr combine g1 g2 g3 g4, cols(2) graphregion(fcolor(white)) note("")
gr rename ga, replace
graph export "$figures/figure4.pdf", replace
graph export "$figures/figure4.png", replace
restore



***============================================================================*
*** Table A4: 
***============================================================================*
*----------------------Balance covariates: table A4
*** Table A4 can be manually reconstructed using the files TableA4a.xls and TableA4b.xls.
preserve
cap erase "$tables/tableA4a.xls"
cap erase "$tables/tableA4b.xls"
logit  $shock1 $covar i.cid i.year
cap drop pihat
cap drop invwt
predict pihat
gen invwt=$shock1/pihat + (1-$shock1)/(1-pihat) if !missing(pihat)
dtable $covar,by(ftreat_prdm_elec,test) continuous($covar ,statistics(mean)) export("$tables/tableA4a.xls", replace sheet("Before"))
dtable $covar [pweight=invwt],by($shock1,test) continuous($covar ,statistics(mean)) export("$tables/tableA4b.xls", replace sheet("After"))
drop pihat
restore
di "Propensity score diagnostics completed"


***============================================================================*
*** Table 3 and Figure A2: 
***============================================================================*

**## - Augmented IPW with doubly robust estimation (logit propensity scores)
**### - LP-AIPW for Renewable Energy Production
di "Estimating LP-AIPW for renewable energy production..."

preserve
qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	** Estimate propensity score (logit)
	logit `treat' $covar `yvar1'_cycle L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4 i.cid i.year 
	predict pihat0
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	** Estimate for each time horizon
	qui forvalues h=0/5 {
		eststo: xtscc `yvar1'`h' `treat' $covar l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').`treat' `yvar1'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		** Doubly robust adjustment
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar1'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar1'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(green) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel A: `mylabel1'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar1', replace
}

restore

**### - LP-AIPW for Renewable Energy Consumption
di "Estimating LP-AIPW for renewable energy consumption..."

preserve
qui foreach treat in $shock1 {
	pause on
	capture drop pihat pihat0
	
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	logit `treat' $covar `yvar2'_cycle i.cid i.year L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4
	predict pihat0
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	qui forvalues h=0/5 {
		eststo: xtscc `yvar2'`h' `treat' $covar l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').`treat' `yvar2'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar2'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar2'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel B: `mylabel2'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar2', replace
}
** Combine and export
gr combine `yvar1' `yvar2', ycommon cols(2) graphregion(fcolor(white)) note("")
gr rename g4, replace
graph export "$figures/figureA2.pdf", replace
graph export "$figures/figureA2.png", replace
restore

** Export table results
preserve
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui gen ATE_IPWRA = 1
label var ATE_IPWRA "Average Treatment Effect"

capture erase "$tables/table3.csv"
capture erase "$tables/table3.tex"

label var ATE_IPWRA "ATE: `mylabel3'"
esttab `yvar1'*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")  ///
    posthead("\midrule" ///
             "\multicolumn{7}{l}{\textit{Panel A: `yvar1'}} \\")

esttab `yvar1'* using "$tables/table3.csv", replace se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar1'* using "$tables/table3.tex", replace se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label booktabs  substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) fragment ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")  ///
	prehead(`preheadA') posthead(`postheadA')

label var ATE_IPWRA "ATE: `mylabel3'"
esttab `yvar2'*, append se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'* using "$tables/table3.csv", append se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'* using "$tables/table3.tex", append se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label booktabs fragment   substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) nonumber nomtitles ///
                posthead(`postheadB') postfoot(`postfootC')
             

restore

di "LP-AIPW (Logit) analysis completed"


***============================================================================*
*** Table 4 and Figure A3: 
***============================================================================*

**# 6.3 Robustesness Check
**### - Alternative method to estimate the propensity score: entropy balancing 
di "Using entropy balancing for covariate balance"

**#### - EB-AIPW for Renewable Energy Production
** ============================================================================*
di ""
di "Entropy Balancing - Production"

preserve
estimates clear

qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0 _webal
	
	** Initialize storage variables
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	di "  Computing entropy balancing propensity scores..."
	
	** Entropy balancing for covariate balance
	ebalfit $covar `yvar1'_cycle i.cid i.year L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4, ///
		by($shock1) baltab
	predict pihat0, pr
	gen pihat = pihat0
	
	** Re-establish panel structure
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	** Estimate treatment effect for each horizon
	qui forvalues h = 0/5 {
		di "    Horizon h=`h'..."
		
		** Main specification with inverse probability weighting
		eststo: xtscc `yvar1'`h' `treat' $covar l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').`treat' `yvar1'_cycle i.year i.cid [aweight=invwt], ase
		
		** Predict potential outcomes
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		
		** Impute counterfactual outcomes
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		** Construct doubly robust estimator
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar1'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		** Extract ATE
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar1'`h'
		
		** Calculate robust standard error
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		** Store for plotting
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		** Cleanup
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	** Create impulse response plot with entropy balancing weights
	twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(green) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel A: `mylabel1'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar1', replace
}

restore

**####- EB-AIPW for Renewable Energy Consumption
** ============================================================================*
di ""
di "Entropy Balancing - Consumption"

preserve
*estimates clear
qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0 _webal
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	di "  Computing entropy balancing propensity scores..."
	
	ebalfit $covar `yvar2'_cycle i.cid L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4, ///
		by($shock1) baltab
	predict pihat0, pr
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	qui forvalues h = 0/5 {
		di "    Horizon h=`h'..."
		
		eststo: xtscc `yvar2'`h' `treat' $covar l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').`treat' `yvar2'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar2'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar2'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel B: `mylabel2'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar2', replace
}

restore


preserve
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
** Combine entropy balancing results
gr combine `yvar1' `yvar2', ycommon cols(2) graphregion(fcolor(white)) note("")
gr rename g4, replace
graph export "$figures/figureA3.pdf", replace
graph export "$figures/figureA3.png", replace
restore
di "Entropy balancing analysis completed and saved"



** Export EB-AIPW results
preserve
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui gen ATE_IPWRA = 1
label var ATE_IPWRA "Average Treatment Effect (EB-AIPW)"

capture erase "$tables/table4.csv"
capture erase "$tables/table4.tex"

label var ATE_IPWRA "ATE-EB: `mylabel3'"
esttab `yvar1'*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar1'* using "$tables/table4.tex", booktabs fragment replace se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")  ///
	prehead(`preheadA') posthead(`postheadA')

esttab `yvar2'* using "$tables/table4.tex", booktabs fragment  append se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) nonumber nomtitles ///
                posthead(`postheadB') postfoot(`postfootC')

restore


***============================================================================*
*** Table A5 and Figure A4: 
***============================================================================*
**### - Alternative method to estimate the propensity score: cloglog
**####- Cloglog-AIPW for Renewable Energy Consumption
di "Cloglog - Production"

preserve
estimates clear
qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	di "  Estimating complementary log-log propensity scores..."
	
	** Estimate cloglog model
	qui xtcloglog `treat' $covar `yvar1'_cycle i.year L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4, ///
		pa tolerance(1) i(cid)
	predict pihat0, mu
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	qui forvalues h = 0/5 {
		di "    Horizon h=`h'..."
		
		eststo: xtscc `yvar1'`h' `treat' $covar l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').`treat' `yvar1'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar1'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar1'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(green) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel A: `mylabel1'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar1', replace
}

restore

**####-  Cloglog-AIPW for Renewable Energy Consumption
** ============================================================================*
di "Cloglog - Consumption"

preserve
*estimates clear
qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	di "  Estimating complementary log-log propensity scores..."
	
	qui xtcloglog `treat' $covar `yvar1'_cycle i.year L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4, ///
		pa tolerance(1) i(cid)
	predict pihat0, mu
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	qui forvalues h = 0/5 {
		di "    Horizon h=`h'..."
		
		eststo: xtscc `yvar2'`h' `treat' $covar l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').`treat' `yvar2'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar2'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar2'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel B: `mylabel2'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar2', replace
}

restore



preserve
local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
** Combine cloglog results
gr combine `yvar1' `yvar2', ycommon cols(2) graphregion(fcolor(white)) note("")
gr rename g4, replace
graph export "$figures/figureA4.pdf", replace
graph export "$figures/figureA4.png", replace
restore


** Export cloglog-AIPW results
preserve
local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui gen ATE_IPWRA = 1
label var ATE_IPWRA "Average Treatment Effect (EB-AIPW)"

capture erase "$tables/tableA5.csv"
capture erase "$tables/tableA5.tex"

label var ATE_IPWRA "ATE-cloglog: `mylabel3'"
esttab `yvar1'*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'*, replace substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar1'* using "$tables/tableA5.tex", booktabs fragment replace se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum") ///
	prehead(`preheadA') posthead(`postheadA')

esttab `yvar2'* using "$tables/tableA5.tex", booktabs fragment append se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) nonumber nomtitles ///
                posthead(`postheadB') postfoot(`postfootC')
	
esttab `yvar1'* using "$tables/tableA5.csv", replace se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

label var ATE_IPWRA "ATE (cloglog): `shock1'"
esttab `yvar2'* using "$tables/tableA5.csv", append se nodepvars ///
	nonotes se(3) b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w RobustSE pvalue, ///
	label("Observations" "Within R-square" "Robust SE" "P-value")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum") 

restore

di "Rare event (cloglog) analysis completed"



***============================================================================*
*** Figure A5: 
***============================================================================*
**###- Accounting for country-level disparities 
di "Excluding each country sequentially"

preserve
    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
pause on 
capture drop pihat pihat0
* make variables
cap drop b u d Years Zero u10 d10
cap drop b1 u1 d1 u101 d101
gen Years = _n-2 if _n<=7
gen Zero =  0    if _n<=7
gen b=0
gen u=0
gen d=0
gen u10=0
gen d10=0

gen b1=0
gen u1=0
gen d1=0
gen u101=0
gen d101=0

logit $shock1 $covar `yvar1'_cycle L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4 i.cid i.year
predict pihat


logit $shock1 $covar `yvar2'_cycle L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4 i.cid i.year 
predict pihat1

* sort again
sort cid year
xtset cid year

foreach foodGroup in BFA	CIV	CMR	DZA	EGY	ETH	GHA	KEN	MAR	MDG	MOZ	NGA	SEN	TUN	TZA	UGA	ZAF	ZWE {
        /// Create individual graphs using a loop
        if "`foodGroup'" == "BFA"             local graphTitle "Burkina Faso "
        if "`foodGroup'" == "CIV"             local graphTitle "Cote d'Ivoire"
        if "`foodGroup'" == "CMR"             local graphTitle "Cameroon"
        if "`foodGroup'" == "DZA"             local graphTitle "Algeria"
		if "`foodGroup'" == "EGY"             local graphTitle "Egypt"
        if "`foodGroup'" == "ETH"             local graphTitle " Ethiopia"
        if "`foodGroup'" == "GHA"             local graphTitle " Ghana"
		
		if "`foodGroup'" == "KEN"             local graphTitle "Kenya"
        if "`foodGroup'" == "MAR"             local graphTitle "Morocco"
        if "`foodGroup'" == "MDG"             local graphTitle "Madagascar"
        if "`foodGroup'" == "MOZ"             local graphTitle "Mozambique"
        if "`foodGroup'" == "NGA"             local graphTitle "Nigeria"
        if "`foodGroup'" == "SEN"             local graphTitle "Senegal"
		
		if "`foodGroup'" == "TUN"             local graphTitle " Tunisia"
        if "`foodGroup'" == "TZA"             local graphTitle "Tanzania"
        if "`foodGroup'" == "UGA"             local graphTitle "Uganda"
        if "`foodGroup'" == "ZAF"             local graphTitle "South Africa"
        if "`foodGroup'" == "ZWE"             local graphTitle " Zimbabwe"
		
local mylabel : variable label $shock1
capture drop a invwt
gen a=$shock1 
gen invwt=a/pihat + (1-a)/(1-pihat) 

*local mylabel : variable label $shock2
capture drop a1
cap drop invwt1
gen a1=$shock1 
gen invwt1=a1/pihat1 + (1-a1)/(1-pihat1) 


forvalues h=0/5 {
	eststo: xtscc `yvar1'`h' $shock1 $covar l(1/4).`yvar1'0  F(1/`=`h'+1').$shock1 `yvar1'_cycle  i.year i.cid [aweight=invwt]  if ccode!="`foodGroup'", ase 
	gen samp=e(sample) // set sample
	predict mu0 if samp==1 & $shock1==0
	predict mu1 if samp==1 & $shock1==1
	replace mu0 = mu1 - _b[$shock1] if samp==1 & $shock1==1
	replace mu1 = mu0 + _b[$shock1] if samp==1 & $shock1==0
	generate mdiff1=(-(a-pihat)*mu1/pihat)-((a-pihat)*mu0/(1-pihat))
	generate iptw=(2*a-1)*`yvar1'`h'*invwt
	generate dr1=iptw+mdiff1
	qui gen ATE_IPWRA=1
	reg dr1 ATE_IPWRA, nocons 
	eststo `yvar1'`h'
	sum dr1
	local dr1m = r(mean)
	gen Isq  = (dr1-`dr1m')^2
	sum Isq
	estadd scalar RobustSE = sqrt(r(mean)/r(N))
	estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))	
	capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	capture scalar drop dr1m
	* store for charts
		replace b = _b[ATE_IPWRA]                     if _n == `h'+2
        replace u = _b[ATE_IPWRA] + 1.96* _se[ATE_IPWRA]    if _n == `h'+2
        replace d = _b[ATE_IPWRA] - 1.96* _se[ATE_IPWRA]    if _n == `h'+2
        replace u10 = _b[ATE_IPWRA] + 1.64* _se[ATE_IPWRA]  if _n == `h'+2
        replace d10 = _b[ATE_IPWRA] - 1.64* _se[ATE_IPWRA]  if _n == `h'+2
	
	
	eststo: xtscc `yvar2'`h' $shock1 $covar l(1/4).`yvar2'0 F(1/`=`h'+1').$shock1 `yvar2'_cycle i.year i.cid [aweight=invwt1]  if ccode!="`foodGroup'", ase
	gen samp1=e(sample) 
	predict mu01 if samp1==1 & $shock1==0 
	predict mu11 if samp1==1 & $shock1==1 
	replace mu01 = mu11 - _b[$shock1] if samp1==1 & $shock1==1 
	replace mu11 = mu01 + _b[$shock1] if samp1==1 & $shock1==0 
	generate mdiff11=(-(a1-pihat1)*mu11/pihat1)-((a1-pihat1)*mu01/(1-pihat1))
	generate iptw1=(2*a1-1)*`yvar2'`h'*invwt1
	generate dr11=iptw+mdiff11
	qui gen ATE_IPWRA1=1 
	reg dr11 ATE_IPWRA1, nocons 
	eststo $shock1`h'
	sum dr11
	local dr1m = r(mean)
	gen Isq1  = (dr1-`dr1m')^2
	sum Isq1
	estadd scalar RobustSE = sqrt(r(mean)/r(N))
	estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))	
	capture drop iptw1 Isq1 mdiff11 dr11 mu11 mu01 samp1 ATE_IPWRA1*
	capture scalar drop dr1m
	* store for charts
		replace b1 = _b[ATE_IPWRA1]                     if _n == `h'+2
        replace u1 = _b[ATE_IPWRA1] + 1.96* _se[ATE_IPWRA1]    if _n == `h'+2
        replace d1 = _b[ATE_IPWRA1] - 1.96* _se[ATE_IPWRA1]    if _n == `h'+2
        replace u101 = _b[ATE_IPWRA1] + 1.64* _se[ATE_IPWRA1]  if _n == `h'+2
        replace d101 = _b[ATE_IPWRA1] - 1.64* _se[ATE_IPWRA1]  if _n == `h'+2
		cap drop samp1
		cap drop mu01
		cap drop mu11
		cap drop mdiff1
		cap drop mdiff11
		cap drop iptw1
	}
* charts

twoway (rarea u d  Years,fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
       (rarea u1 d1  Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
       (rarea u10 d10 Years,fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
	   (rarea u101 d101 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
	   (line b Years,lcolor(green%50) lpattern(solid) lwidth(thick)) ///
	   (line b1 Years,lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
	   (line Zero Years, lcolor(black)), legend(order( 5 "ATE: `mylabel1'" 6 "ATE: `mylabel2'") cols(2) pos(6) size(tiny))  subtitle("Excluded country: `graphTitle'", color(black) size(vsmall)) ///
	   ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) xlab(-1(1)5, nogrid)
gr rename `foodGroup' , replace
}

grc1leg    BFA	CIV	CMR	DZA	EGY	ETH	GHA	KEN	MAR	MDG	MOZ	NGA	SEN	TUN	TZA	UGA	ZAF	ZWE, cols(5) ///
          title("", justification(center) color(black) span pos(17)) ///
                graphregion( color(white)) plotregion(color(white)) 
				
gr rename g4 ,  replace
graph export "$figures/figureA5.pdf", replace
graph export "$figures/figureA5.png", replace	
restore	



***============================================================================*
*** Table 5 and Figure A6: 
***============================================================================*
*==============================================================================*
**#6.4 Conditional Impacts of Electricity Market Reforms: The Role of PPPs
*==============================================================================*
di "Analyzing differential reform impacts by PPP presence"
** Create binary indicator for PPP involvement
gen ppp_treatment = (fppp_energy > 0) if !missing(fppp_energy)
label var ppp_treatment "Indicator for PPP involvement,t+1"

** Label PPP groups
label define ppp_label 0 "Non-PPP" 1 "PPP"
label values ppp_treatment ppp_label

** Generate absence of PPP
gen non_ppp_treatment = 1 - ppp_treatment
** Summary statistics on PPP distribution
di "PPP Treatment Groups Distribution:"
tabulate ppp_treatment, missing



preserve
** Initialize storage variables for visualization
capture drop LPIV* LPIP* _Year
gen LPIVboom = .
gen LPIVslump = .
gen LPIVboomse = .
gen LPIVslumpse = .
gen LPIPboom = .
gen LPIPslump = .
gen LPIPboomse = .
gen LPIPslumpse = .
gen _Years = _n-2 if _n<=7
gen _Zero = 0 if _n<=7
label var _Years "Year"

** Initialize coefficient storage for plots
cap drop b u d Years Zero u10 d10
cap drop b1 u1 d1 u101 d101

gen Years = _n-2 if _n<=7
gen Zero = 0 if _n<=7
gen b = 0
gen u = 0
gen d = 0
gen u10 = 0
gen d10 = 0
gen b1 = 0
gen u1 = 0
gen d1 = 0
gen u101 = 0
gen d101 = 0

    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1

** Estimate propensity scores (pooled sample)
di "  Estimating propensity scores for production outcomes..."
capture drop pihat pihat0
qui logit $shock1 $covar `yvar1'_cycle L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4 i.cid i.year 
predict pihat0, pr
gen pihat = pihat0

** Prepare data structure
sort cid year
xtset cid year

** Compute inverse probability weights
capture drop a invwt
gen a = $shock1
gen invwt = a/pihat0 + (1-a)/(1-pihat0) if pihat~=.

di "  Estimation loop: Production outcomes across horizons..."

** Loop over time horizons
qui forvalues h = 0/5 {
	di "    Horizon h=`h' - Estimating PPP and Non-PPP effects..."
	
	** Reset temporary variables
	capture scalar drop dr1m
	capture drop mu1 mu0
	gen mu0 = .
	gen mu1 = .
	
	** Estimate for each group (PPP vs Non-PPP)
	foreach group in ppp_treatment non_ppp_treatment {
		** Determine group label for output
		if "`group'" == "ppp_treatment" {
			local group_label "PPP"
		}
		else {
			local group_label "Non-PPP"
		}
		
		di "      Estimating for `group_label' subsample..."
		
		** Estimate xtscc with inverse probability weights within group
		qui xtscc `yvar1'`h' $shock1 $covar l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').$shock1 `yvar1'_cycle i.year i.cid [aweight=invwt] ///
			if `group'==1, ase
		
		** Identify observations in sample
		gen samp = e(sample)
		
		** Predict outcome values
		predict temp, xb
		
		** Assign predictions to potential outcome variables
		replace mu0 = temp if samp==1 & $shock1==0 & `group'==1
		replace mu1 = temp if samp==1 & $shock1==1 & `group'==1
		
		** Impute counterfactual outcomes
		replace mu0 = mu1 - _b[$shock1] if samp==1 & $shock1==1 & `group'==1
		replace mu1 = mu0 + _b[$shock1] if samp==1 & $shock1==0 & `group'==1
		
		capture drop samp temp
	}
	
	** Construct doubly robust estimator
	di "      Computing doubly robust estimates..."
	capture drop mdiff1 iptw dr1 Isq ATE_IPWRA*
	
	** Augmentation component (g-computation residuals)
	generate mdiff1 = (-(a-pihat0)*mu1/pihat0) - ((a-pihat0)*mu0/(1-pihat0))
	
	** Inverse probability term
	generate iptw = (2*a-1)*`yvar1'`h'*invwt
	
	** Doubly robust combination
	generate dr1 = iptw + mdiff1
	
	** Calculate mean for robust variance estimation
	sum dr1
	local dr1m = r(mean)
	
	** Store squared residuals for variance
	gen Isq = (dr1-`dr1m')^2
	
	** Create group indicators for stratified estimation
	qui gen ATE_IPWRA_ppp = ppp_treatment
	qui gen ATE_IPWRA_non_ppp = non_ppp_treatment
	
	** Estimate separate effects by group
	di "      Testing for heterogeneity (Wald test)..."
	reg dr1 ATE_IPWRA_ppp ATE_IPWRA_non_ppp, nocons
	
	** Store estimates
	eststo DR_Production_`h'
	
	** Test for differential effects (PPP vs Non-PPP)
	testnl _b[ATE_IPWRA_ppp] = _b[ATE_IPWRA_non_ppp]
	local chi2_test = r(chi2)
	local pvalue_test = r(p)
	estadd scalar Chi2_Difference = `chi2_test'
	estadd scalar p_Heterogeneity = `pvalue_test'
	
	** Store for visualization (PPP)
	replace LPIPboom = _b[ATE_IPWRA_ppp] if _n == `h'+1
	replace LPIPboomse = _se[ATE_IPWRA_ppp] if _n == `h'+1
	replace b = _b[ATE_IPWRA_ppp] if _n == `h'+2
	replace u = _b[ATE_IPWRA_ppp] + 1.96*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace d = _b[ATE_IPWRA_ppp] - 1.96*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace u10 = _b[ATE_IPWRA_ppp] + 1.64*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace d10 = _b[ATE_IPWRA_ppp] - 1.64*_se[ATE_IPWRA_ppp] if _n == `h'+2
	
	** Store for visualization (Non-PPP)
	replace LPIPslump = _b[ATE_IPWRA_non_ppp] if _n == `h'+1
	replace LPIPslumpse = _se[ATE_IPWRA_non_ppp] if _n == `h'+1
	replace b1 = _b[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace u1 = _b[ATE_IPWRA_non_ppp] + 1.96*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace d1 = _b[ATE_IPWRA_non_ppp] - 1.96*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace u101 = _b[ATE_IPWRA_non_ppp] + 1.64*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace d101 = _b[ATE_IPWRA_non_ppp] - 1.64*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	
	** Calculate robust standard errors by group
	sum dr1 if ppp_treatment==1
	local dr1m_ppp = r(mean)
	sum Isq if ppp_treatment==1
	estadd scalar RobustSE_PPP = sqrt(r(mean)/r(N))
	estadd scalar pvalue_PPP = normal(`dr1m_ppp'/sqrt(r(mean)/r(N)))
	
	sum dr1 if non_ppp_treatment==1
	local dr1m_non_ppp = r(mean)
	sum Isq if non_ppp_treatment==1
	estadd scalar RobustSE_NonPPP = sqrt(r(mean)/r(N))
	estadd scalar pvalue_NonPPP = normal(`dr1m_non_ppp'/sqrt(r(mean)/r(N)))
	
	** Cleanup temporary variables
	capture drop iptw Isq mdiff1 dr1 mu1 mu0 ATE_IPWRA*
}

** Create impulse response plot for PPP subsample
di ""
di "Creating visualization for production outcomes..."

twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
	(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
	(line b Years, lcolor(red) lpattern(solid) lwidth(thick)) ///
	(line Zero Years, lcolor(black)), ///
	legend(off) ///
	subtitle("AIPW Estimates: PPP projects", color(black) size(vsmall)) ///
	ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) ///
	ylab(, nogrid) xlab(-1(1)5, nogrid)
gr rename g1a, replace

** Create impulse response plot for Non-PPP subsample
twoway (rarea u1 d1 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
	(rarea u101 d101 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
	(line b1 Years, lcolor(blue) lpattern(solid) lwidth(thick)) ///
	(line Zero Years, lcolor(black)), ///
	legend(off) ///
	subtitle("AIPW Estimates: Non-PPP Projects", color(black) size(vsmall)) ///
	ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) ///
	ylab(, nogrid) xlab(-1(1)5, nogrid)
gr rename g1b, replace

** Combine subsamples into one plot
gr combine g1a g1b, title("(a) `mylabel1' - Production", color(black) size(vsmall))
graph rename ga, replace

restore


*** LP-AIPW FOR CONSUMPTION - PPP HETEROGENEITY

preserve

** Reset working variables
capture drop pihat pihat0
global covar "lpwt_hci lwdi_trade linflation_imf lwdi_fdiin lwdi_agedr lIMF55 lany_election lFD ltotal_natural_resources_rents lwdi_gdpgr lyrcurnt llogwdi_pop licrg_qog"

capture drop LPIV* LPIP* _Year
gen LPIVboom = .
gen LPIVslump = .
gen LPIVboomse = .
gen LPIVslumpse = .
gen LPIPboom = .
gen LPIPslump = .
gen LPIPboomse = .
gen LPIPslumpse = .
gen _Years = _n-2 if _n<=7
gen _Zero = 0 if _n<=7
label var _Years "Year"

cap drop b u d Years Zero u10 d10
cap drop b1 u1 d1 u101 d101

gen Years = _n-2 if _n<=7
gen Zero = 0 if _n<=7
gen b = 0
gen u = 0
gen d = 0
gen u10 = 0
gen d10 = 0
gen b1 = 0
gen u1 = 0
gen d1 = 0
gen u101 = 0
gen d101 = 0


    local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
** Estimate propensity scores (consumption model)
di "  Estimating propensity scores for consumption outcomes..."
capture drop pihat pihat0
qui logit $shock1 $covar `yvar2'_cycle i.cid i.year L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4
predict pihat0, pr
gen pihat = pihat0

sort cid year
xtset cid year

capture drop a invwt
gen a = $shock1
gen invwt = a/pihat0 + (1-a)/(1-pihat0) if pihat~=.

di "  Estimation loop: Consumption outcomes across horizons..."

** Loop over time horizons
qui forvalues h = 0/5 {
	di "    Horizon h=`h' - Estimating PPP and Non-PPP effects..."
	
	capture scalar drop dr1m
	capture drop mu1 mu0
	gen mu0 = .
	gen mu1 = .
	
	** Estimate for PPP and Non-PPP groups
	foreach group in ppp_treatment non_ppp_treatment {
		if "`group'" == "ppp_treatment" {
			local group_label "PPP"
		}
		else {
			local group_label "Non-PPP"
		}
		
		di "      Estimating for `group_label' subsample..."
		
		qui xtscc `yvar2'`h' $shock1 $covar l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').$shock1 `yvar2'_cycle i.year i.cid [aweight=invwt] ///
			if `group'==1, ase
		
		gen samp = e(sample)
		predict temp, xb
		replace mu0 = temp if samp==1 & $shock1==0 & `group'==1
		replace mu1 = temp if samp==1 & $shock1==1 & `group'==1
		replace mu0 = mu1 - _b[$shock1] if samp==1 & $shock1==1 & `group'==1
		replace mu1 = mu0 + _b[$shock1] if samp==1 & $shock1==0 & `group'==1
		
		capture drop samp temp
	}
	
	** Doubly robust estimation
	di "      Computing doubly robust estimates..."
	capture drop mdiff1 iptw dr1 Isq ATE_IPWRA*
	generate mdiff1 = (-(a-pihat0)*mu1/pihat0) - ((a-pihat0)*mu0/(1-pihat0))
	generate iptw = (2*a-1)*`yvar2'`h'*invwt
	generate dr1 = iptw + mdiff1
	
	sum dr1
	local dr1m = r(mean)
	gen Isq = (dr1-`dr1m')^2
	
	qui gen ATE_IPWRA_ppp = ppp_treatment
	qui gen ATE_IPWRA_non_ppp = non_ppp_treatment
	
	di "      Testing for heterogeneity (Wald test)..."
	reg dr1 ATE_IPWRA_ppp ATE_IPWRA_non_ppp, nocons
	
	eststo DR_Consumption_`h'
	
	testnl _b[ATE_IPWRA_ppp] = _b[ATE_IPWRA_non_ppp]
	local chi2_test = r(chi2)
	local pvalue_test = r(p)
	estadd scalar Chi2_Difference = `chi2_test'
	estadd scalar p_Heterogeneity = `pvalue_test'
	
	** Store coefficients (PPP)
	replace LPIPboom = _b[ATE_IPWRA_ppp] if _n == `h'+1
	replace LPIPboomse = _se[ATE_IPWRA_ppp] if _n == `h'+1
	replace b = _b[ATE_IPWRA_ppp] if _n == `h'+2
	replace u = _b[ATE_IPWRA_ppp] + 1.96*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace d = _b[ATE_IPWRA_ppp] - 1.96*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace u10 = _b[ATE_IPWRA_ppp] + 1.64*_se[ATE_IPWRA_ppp] if _n == `h'+2
	replace d10 = _b[ATE_IPWRA_ppp] - 1.64*_se[ATE_IPWRA_ppp] if _n == `h'+2
	
	** Store coefficients (Non-PPP)
	replace LPIPslump = _b[ATE_IPWRA_non_ppp] if _n == `h'+1
	replace LPIPslumpse = _se[ATE_IPWRA_non_ppp] if _n == `h'+1
	replace b1 = _b[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace u1 = _b[ATE_IPWRA_non_ppp] + 1.96*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace d1 = _b[ATE_IPWRA_non_ppp] - 1.96*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace u101 = _b[ATE_IPWRA_non_ppp] + 1.64*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	replace d101 = _b[ATE_IPWRA_non_ppp] - 1.64*_se[ATE_IPWRA_non_ppp] if _n == `h'+2
	
	** Robust standard errors
	sum dr1 if ppp_treatment==1
	local dr1m_ppp = r(mean)
	sum Isq if ppp_treatment==1
	estadd scalar RobustSE_PPP = sqrt(r(mean)/r(N))
	estadd scalar pvalue_PPP = normal(`dr1m_ppp'/sqrt(r(mean)/r(N)))
	
	sum dr1 if non_ppp_treatment==1
	local dr1m_non_ppp = r(mean)
	sum Isq if non_ppp_treatment==1
	estadd scalar RobustSE_NonPPP = sqrt(r(mean)/r(N))
	estadd scalar pvalue_NonPPP = normal(`dr1m_non_ppp'/sqrt(r(mean)/r(N)))
	
	capture drop iptw Isq mdiff1 dr1 mu1 mu0 ATE_IPWRA*
}

** Create visualization for consumption
di ""
di "Creating visualization for consumption outcomes..."

twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
	(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
	(line b Years, lcolor(red) lpattern(solid) lwidth(thick)) ///
	(line Zero Years, lcolor(black)), ///
	legend(off) ///
	subtitle("AIPW Estimates: PPP Projects", color(black) size(vsmall)) ///
	ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) ///
	ylab(, nogrid) xlab(-1(1)5, nogrid)
gr rename g2a, replace

twoway (rarea u1 d1 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
	(rarea u101 d101 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
	(line b1 Years, lcolor(blue) lpattern(solid) lwidth(thick)) ///
	(line Zero Years, lcolor(black)), ///
	legend(off) ///
	subtitle("AIPW Estimates: Non-PPP Projects", color(black) size(vsmall)) ///
	ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
	graphregion(color(white)) plotregion(color(white)) ///
	ylab(, nogrid) xlab(-1(1)5, nogrid)
gr rename g2b, replace

gr combine g2a g2b, title("(b) `mylabel2' - Consumption", color(black) size(vsmall))
graph rename gb, replace

restore

di ""
di "=========================================================="
di "Exporting Results and Visualizations"
di "=========================================================="

** Combine both outcome plots
gr combine ga gb, cols(1) graphregion(fcolor(white)) note("")
gr rename g4, replace
graph export "$figures/figureA6.pdf", replace
graph export "$figures/figureA6.png", replace

di "  Plots saved to $figures/figureA6"

** Export production estimates
di ""
di "Exporting heterogeneity tables..."
capture  erase "$tables/table5.csv"
capture  erase "$tables/table5.tex"

esttab DR_Production_0 DR_Production_1 DR_Production_2 ///
	DR_Production_3 DR_Production_4 DR_Production_5, replace ///
	title("Table 10A: Heterogeneous Treatment Effects - Production (PPP vs Non-PPP)") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab DR_Production_0 DR_Production_1 DR_Production_2 ///
	DR_Production_3 DR_Production_4 DR_Production_5 using "$tables/table5.tex", booktabs fragment  replace ///
	title("Heterogeneous Treatment Effects - Production") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum") ///
	prehead(`preheadA') posthead(`postheadA')

esttab DR_Production_0 DR_Production_1 DR_Production_2 ///
	DR_Production_3 DR_Production_4 DR_Production_5 using "$tables/table5.csv", replace ///
	title("Heterogeneous Treatment Effects - Production") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum") posthead("\midrule" ///
             "\multicolumn{7}{l}{\textit{Panel A: `mylabel1'}} \\")

** Export consumption estimates
esttab DR_Consumption_0 DR_Consumption_1 DR_Consumption_2 ///
	DR_Consumption_3 DR_Consumption_4 DR_Consumption_5, replace ///
	title("Table 10B: Heterogeneous Treatment Effects - Consumption (PPP vs Non-PPP)") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab DR_Consumption_0 DR_Consumption_1 DR_Consumption_2 ///
	DR_Consumption_3 DR_Consumption_4 DR_Consumption_5 using "$tables/table5.tex", booktabs fragment append ///
	title("Heterogeneous Treatment Effects - Consumption") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") nonumber nomtitles ///
                posthead(`postheadB') postfoot(`postfootC')

esttab DR_Consumption_0 DR_Consumption_1 DR_Consumption_2 ///
	DR_Consumption_3 DR_Consumption_4 DR_Consumption_5 using "$tables/table5.csv", append ///
	title("Heterogeneous Treatment Effects - Consumption") ///
	scalars(Chi2_Difference p_Heterogeneity RobustSE_PPP pvalue_PPP RobustSE_NonPPP pvalue_NonPPP) ///
	b(3) se(3) sfmt(2) obslast label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") nonum ///
	star(* 0.10 ** 0.05 *** 0.01) ///
	coeflabels(ATE_IPWRA_ppp "PPP" ATE_IPWRA_non_ppp "Non-PPP") ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

*** =============================================================================
*** END OF ANALYSIS
*** =============================================================================




**# Addition control (not reported)

global covar2 "lprdm_tel ltrade ldomfin llabor llogwdi_popden lgini lwdi_co2"
preserve

qui foreach treat in $shock1 {
	pause on
	capture drop pihat pihat0
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	** Estimate propensity score (logit)
	logit `treat' $covar `yvar1'_cycle L`yvar1'1 L`yvar1'2 L`yvar1'3 L`yvar1'4 i.cid i.year 
	predict pihat0
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	** Estimate for each time horizon
	qui forvalues h=0/5 {
		eststo: xtscc `yvar1'`h' `treat' $covar $covar2 l(1/4).`yvar1'0 ///
			F(1/`=`h'+1').`treat' `yvar1'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		** Doubly robust adjustment
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar1'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar1'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(green%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(green) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel A: `mylabel1'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar1', replace
}

restore

**### - LP-AIPW for Renewable Energy Consumption
di "Estimating LP-AIPW for renewable energy consumption..."

preserve
qui foreach treat in $shock1 {
	local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
	pause on
	capture drop pihat pihat0
	
	cap drop b u d Years Zero u10 d10
	gen Years = _n-2 if _n<=7
	gen Zero = 0 if _n<=7
	gen b = 0
	gen u = 0
	gen d = 0
	gen u10 = 0
	gen d10 = 0
	
	logit `treat' $covar `yvar2'_cycle i.cid i.year L`yvar2'1 L`yvar2'2 L`yvar2'3 L`yvar2'4
	predict pihat0
	gen pihat = pihat0
	
	sort cid year
	xtset cid year
	
	local mylabel : variable label `treat'
	capture drop a invwt
	gen a = `treat'
	gen invwt = a/pihat + (1-a)/(1-pihat)
	
	qui forvalues h=0/5 {
		eststo: xtscc `yvar2'`h' `treat' $covar $covar2 l(1/4).`yvar2'0 ///
			F(1/`=`h'+1').`treat' `yvar2'_cycle i.year i.cid [aweight=invwt], ase
		
		gen samp = e(sample)
		predict mu0 if samp==1 & `treat'==0
		predict mu1 if samp==1 & `treat'==1
		replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1
		replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0
		
		generate mdiff1 = (-(a-pihat)*mu1/pihat) - ((a-pihat)*mu0/(1-pihat))
		generate iptw = (2*a-1)*`yvar2'`h'*invwt
		generate dr1 = iptw + mdiff1
		
		qui gen ATE_IPWRA = 1
		reg dr1 ATE_IPWRA, nocons
		eststo `yvar2'`h'
		
		sum dr1
		local dr1m = r(mean)
		gen Isq = (dr1-`dr1m')^2
		sum Isq
		estadd scalar RobustSE = sqrt(r(mean)/r(N))
		estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
		
		replace b = _b[ATE_IPWRA] if _n == `h'+2
		replace u = _b[ATE_IPWRA] + 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace d = _b[ATE_IPWRA] - 1.96*_se[ATE_IPWRA] if _n == `h'+2
		replace u10 = _b[ATE_IPWRA] + 1.64*_se[ATE_IPWRA] if _n == `h'+2
		replace d10 = _b[ATE_IPWRA] - 1.64*_se[ATE_IPWRA] if _n == `h'+2
		
		capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
	}
	
	twoway (rarea u d Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(rarea u10 d10 Years, fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
		(line b Years, lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
		(line Zero Years, lcolor(black)), ///
		legend(order(3 "ATE estimates") cols(2) pos(6)) ///
		subtitle("{bf}Panel B: `mylabel2'", color(black) size(2)) ///
		ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
		graphregion(color(white)) plotregion(color(white)) ///
		ylab(, nogrid) xlab(-1(1)5, nogrid)
	gr rename `yvar2', replace
}

restore

** Combine and export
gr combine `yvar1' `yvar2', ycommon cols(2) graphregion(fcolor(white)) note("")
gr rename g4, replace
graph export "$figures/figureA7.pdf", replace
graph export "$figures/figureA7.png", replace

** Export table results
preserve
local yvar1 "logrenew_elec_share"
    local yvar2 "logwdi_enerenew"
	local mylabel1 : variable label $yvar1
    local mylabel2 : variable label $yvar2
    local mylabel3 : variable label $shock1
qui gen ATE_IPWRA = 1
label var ATE_IPWRA "Average Treatment Effect"

capture erase "$tables/tableA7.csv"
capture erase "$tables/tableA7.tex"

label var ATE_IPWRA "ATE: `mylabel3'"
esttab `yvar1'*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")  ///
    posthead("\midrule" ///
             "\multicolumn{7}{l}{\textit{Panel A: `yvar1'}} \\")

esttab `yvar1'* using "$tables/tableA7.csv", replace se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar1'* using "$tables/tableA7.tex", replace se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label booktabs  substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) fragment ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")  ///
	prehead(`preheadA') posthead(`postheadA')

label var ATE_IPWRA "ATE: `mylabel3'"
esttab `yvar2'*, append se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
	sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'* using "$tables/tableA7.csv", append se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) ///
    mtitles("Year 0" "Year 1" "Year 2" "Year 3" "Year 4" "Sum")

esttab `yvar2'* using "$tables/tableA7.tex", append se nodepvars nonotes se(3) ///
	b(3) sfmt(a3) label booktabs fragment   substitute("%" "\%" /*"$" "\$" "&" "\&" /// */"_" "\_") varlabels(_cons Constant) ///
	star(* 0.10 ** 0.05 *** 0.01) stats(N r2_w, label("Observations" "Within R-square")) keep(ATE_IPWRA) nonumber nomtitles ///
                posthead(`postheadB') postfoot(`postfootC')
restore


di ""
di "Output files saved to:"
di "  Tables: $tables"
di "  Figures: $figures"
di "=========================================================="
