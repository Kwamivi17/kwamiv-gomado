*==============================================================================
* Fig5 and TableB1
*==============================================================================

clear all
set matsize 11000,permanently
set mem 1000m
set more off

* inputs
global homedir "/Users/kwamivigomado/Downloads/Unemployment impact of network sectors and employment protection legislation reforms"
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

* Import datasets
use "$datasets/MAIN_DATASETS.dta",clear

xtset cid year
sort cid year

* Control variable
* global covar "lpwt_hci linflation_imf polity2_jorra lgdp_growth_jorra IMF55 crisis_dummy lwdi_fdiin lwdi_trade any_election labor_market product_market yrcurnt lggfce_gdp"

global covar "lpwt_hci linflation_imf any_election yrcurnt crisis_dummy IMF55  polity2_jorra lwdi_trade lgini lgdp_growth_jorra labor_market product_market"

* Reform variable (Change vs episodes or shock)
global reform1 "labor_market_reform"
global reform2 "product_market_reform"

global shock1 "ftreat_light_labor"
global shock2 "ftreat_light_prdm"

* Dependent variable
global yvar1 "wdi_unempilo"

* Horizon
global min 0
global max 5

* Colors
global bcolor1 blue
global bcolor2 red
global iccolor black

local mylabel1 : variable label $shock1
local mylabel2 : variable label $shock2

* --- LP-OLS: Change in indicator ---

* Labor market reforms
preserve
estimates clear
foreach v in $reform1{
    cap drop b u d Years Zero u10 d10
    gen Years = _n-2 if _n<=7
    gen Zero = 0 if _n<=7
    gen b=0
    gen u=0
    gen d=0
    gen u10=0
    gen d10=0
    local mylabel : variable label `v'
    qui forv h = 0/5 {
        eststo `v'`h': xtscc $yvar1`h' `v' $covar i.year, ase fe lag(`=`h' + 1')
        replace b = _b[`v'] if _n == `h'+2
        replace u = _b[`v'] + 1.96* _se[`v'] if _n == `h'+2
        replace d = _b[`v'] - 1.96* _se[`v'] if _n == `h'+2
        replace u10 = _b[`v'] + 1.64* _se[`v'] if _n == `h'+2
        replace d10 = _b[`v'] - 1.64* _se[`v'] if _n == `h'+2
    }

    twoway (rarea u d Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u10 d10 Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (line b Years,lcolor(purple) lpattern(solid) lwidth(thick)) ///
        (line Zero Years, lcolor(black)), legend(order(3 "ATE: `mylabel1'") cols(2) pos(6)) ///
        subtitle("{bf}Panel A: `mylabel'(Change) ", color(black) size(vsmall)) ///
        ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
        graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
        xlab(-1(1)5, nogrid)

    gr rename `v' , replace
    graph export "$figures/figureA.pdf", replace
    * graph save   "$figures\lpc.gph", replace
}

capture erase "$tables/tableB1.csv"
capture erase "$tables/tableB1.tex"

esttab $reform1*, replace se keep($reform1) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab using "$tables/tableB1.csv", replace se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($reform1)
esttab using "$tables/tableB1.tex", replace se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($reform1)

restore

* Product market reforms
preserve
estimates clear
foreach v in $reform2{
    cap drop b u d Years Zero u10 d10
    gen Years = _n-2 if _n<=7
    gen Zero = 0 if _n<=7
    gen b=0
    gen u=0
    gen d=0
    gen u10=0
    gen d10=0
    local mylabel : variable label `v'
    qui forv h = 0/5 {
        eststo `v'`h': xtscc $yvar1`h' `v' $covar i.year, ase fe lag(`=`h' + 1')
        replace b = _b[`v'] if _n == `h'+2
        replace u = _b[`v'] + 1.96* _se[`v'] if _n == `h'+2
        replace d = _b[`v'] - 1.96* _se[`v'] if _n == `h'+2
        replace u10 = _b[`v'] + 1.64* _se[`v'] if _n == `h'+2
        replace d10 = _b[`v'] - 1.64* _se[`v'] if _n == `h'+2
    }

    twoway (rarea u d Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u10 d10 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (line b Years,lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
        (line Zero Years, lcolor(black)), legend(order(3 "ATE: `mylabel2'") cols(2) pos(6)) ///
        subtitle("{bf}Panel C: `mylabel'(Change) ", color(black) size(vsmall)) ///
        ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
        graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
        xlab(-1(1)5, nogrid)
    gr rename `v' , replace
    graph export "$figures/figureC.pdf", replace
}

esttab $reform2*, replace se keep($reform2) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab using "$tables/tableB1.csv", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($reform2)
esttab using "$tables/tableB1.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($reform2)
restore

*------------------------------------------------------------------------------
* LP-OLS: reforms episodes
*------------------------------------------------------------------------------

* Labor market reforms episodes
preserve
estimates clear
foreach v in $shock1{
    cap drop b u d Years Zero u10 d10
    gen Years = _n-2 if _n<=7
    gen Zero = 0 if _n<=7
    gen b=0
    gen u=0
    gen d=0
    gen u10=0
    gen d10=0
    local mylabel : variable label `v'
    qui forv h = 0/5 {
        eststo `v'`h': xtscc $yvar1`h' `v' $covar i.year, ase fe lag(`=`h' + 1')
        replace b = _b[`v'] if _n == `h'+2
        replace u = _b[`v'] + 1.96* _se[`v'] if _n == `h'+2
        replace d = _b[`v'] - 1.96* _se[`v'] if _n == `h'+2
        replace u10 = _b[`v'] + 1.64* _se[`v'] if _n == `h'+2
        replace d10 = _b[`v'] - 1.64* _se[`v'] if _n == `h'+2
    }

    twoway (rarea u d Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u10 d10 Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (line b Years,lcolor(purple) lpattern(solid) lwidth(thick)) ///
        (line Zero Years, lcolor(black)), ///
        legend(order(3 "ATE: `mylabel1'") cols(2) pos(6) size(vsmall) ) ///
        subtitle("{bf}Panel B: `mylabel'(Episodes) ", color(black) size(vsmall)) ///
        ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
        graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
        xlab(-1(1)5, nogrid)

    gr rename `v' , replace
    graph export "$figures/lpc.pdf", replace
    * graph save   "$figures\lpc.gph", replace
}

esttab $shock1*, append se keep($shock1) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label ///
    varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab using "$tables/tableB1.csv", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($shock1)
esttab using "$tables/tableB1.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($shock1)

restore

* Product market reforms episodes
preserve
estimates clear
foreach v in $shock2{
    cap drop b u d Years Zero u10 d10
    gen Years = _n-2 if _n<=7
    gen Zero = 0 if _n<=7
    gen b=0
    gen u=0
    gen d=0
    gen u10=0
    gen d10=0
    local mylabel : variable label `v'
    qui forv h = 0/5 {
        eststo `v'`h': xtscc $yvar1`h' `v' $covar i.year, ase fe lag(`=`h' + 1')
        replace b = _b[`v'] if _n == `h'+2
        replace u = _b[`v'] + 1.96* _se[`v'] if _n == `h'+2
        replace d = _b[`v'] - 1.96* _se[`v'] if _n == `h'+2
        replace u10 = _b[`v'] + 1.64* _se[`v'] if _n == `h'+2
        replace d10 = _b[`v'] - 1.64* _se[`v'] if _n == `h'+2
    }

    twoway (rarea u d Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u10 d10 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (line b Years,lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
        (line Zero Years, lcolor(black)), legend(order(3 "ATE: `mylabel2'") cols(2) pos(6)) ///
        subtitle("{bf}Panel D: `mylabel'(Episodes) ", color(black) size(vsmall)) ///
        ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
        graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
        xlab(-1(1)5, nogrid)
    gr rename `v' , replace
    graph export "$figures/figureD.pdf", replace
}

esttab $shock2*, replace se keep($shock2) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label ///
    varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab using "$tables/tableB1.csv", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($shock2)
esttab using "$tables/tableB1.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep($shock2)
restore

* Now combining the plots together
grc1leg $reform1 $shock1, cols(2) graphregion(fcolor(white)) note("")
gr rename gA , replace
graph export "$figures/figure5.png", replace
graph export "$figures/figure5.pdf", replace

grc1leg $reform2 $shock2, cols(2) graphregion(fcolor(white)) note("")
gr rename gB , replace
graph export "$figures/figure5.png", replace
graph export "$figures/figure5.pdf", replace

graph combine gA gB, cols(1) graphregion(fcolor(white)) note("")
gr rename gC , replace
graph export "$figures/figure5.png", replace
graph export "$figures/figure5.pdf", replace
