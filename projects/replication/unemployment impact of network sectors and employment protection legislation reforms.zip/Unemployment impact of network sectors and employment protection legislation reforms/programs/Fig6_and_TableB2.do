*==============================================================================
* Fig6 and Table B2
*==============================================================================

clear all
set matsize 11000,permanently
set mem 1000m
set more off

* inputs
global homedir "/Users/kwamivigomado/Downloads/Unemployment impact of network sectors and employment protection legislation reforms"
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

* Import datasets
use "$datasets/MAIN_DATASETS.dta",clear

xtset cid year
sort cid year

* Control variable
global covar "lpwt_hci linflation_imf any_election yrcurnt crisis_dummy IMF55  polity2_jorra lwdi_trade lgini lgdp_growth_jorra labor_market product_market"

* Reform variable (Change vs episodes or shock)
global reform1 "labor_market_reform"
global reform2 "product_market_reform"

global shock1 "ftreat_light_labor"
global shock2 "ftreat_light_prdm"

* Dependent variable
global yvar1 "wdi_unempilo"

* Horizon
global min 0
global max 5

* Colors
global bcolor1 blue
global bcolor2 red
global iccolor black

local mylabel1 : variable label $shock1
local mylabel2 : variable label $shock2
preserve
global psvar $covar $yvar1

* --- Roc Curve: Figure 6 ---

capture drop phatm
xtcloglog treat_light_labor $psvar, pa nolog i(cid)

qui predict phatm
roctab treat_light_labor phatm
local auc = r(area)
local se = r(se)
eststo auc
estadd scalar Model_AUC = r(area)
estadd scalar se = r(se)
margins, dydx(*) post
eststo m
roctab treat_light_labor phatm, graph legend(on ring(0) col(2) pos(6) lpattern(dash) ) ///
    mlcolor(red) msize(tiny) ylab(, nogrid) xlab(, nogrid) graphregion(fcolor(white)) ///
    title("Panel A) `mylabel1' ",size(2)) ///
    scheme(s1color)
gr rename gtreat_labor1 , replace
* graph export "$figures/figureRoctreat_labor1.pdf", replace
* graph save   "$figures/figureRoctreat_labor1.gph", replace

capture drop phatm
xtcloglog treat_light_prdm $psvar, pa nolog i(cid)
qui predict phatm
roctab treat_light_prdm phatm
local auc = r(area)
local se = r(se)
eststo auc
estadd scalar Model_AUC = r(area)
estadd scalar se = r(se)
margins, dydx(*) post
eststo m
roctab treat_light_prdm phatm, graph legend(on ring(0) col(2) pos(5) lpattern(dash) ) ///
    mlcolor(red) msize(tiny) ylab(, nogrid) xlab(, nogrid) graphregion(fcolor(white)) ///
    title("Panel B) `mylabel2' ",size(2)) ///
    scheme(s1color)
gr rename gtreat_prdm1 , replace
* graph export "$figures/figureROCtreat_prdm1.pdf", replace
* graph save   "$figures/figureRoctreat_prdm1.gph", replace

* set scheme s1color
grc1leg gtreat_labor1 gtreat_prdm1, col(2) ycommon plotregion(fcolor(white)) ///
    plotregion(fcolor(white)) ///
    title("A. ROC curves for predicting large change in different pro-market institutions",size(small))
* gr combine f1 f2, ycommon title("") graphregion(fcolor(white))
graph rename ga,replace
* graph export "$figures/figure_roc.pdf", replace

* --- Covariable balancing ---

cap drop _pscore
xtcloglog treat_light_labor $psvar, pa nolog i(cid)
predict _pscore
twoway (kdensity _pscore if treat_light_labor==1, lpattern(dash) color(red) lwidth(medthick)) ///
    (kdensity _pscore if treat_light_labor==0, color(blue) lwidth(thick)), ///
    text(2.9 .16 "Control units", placement(e) color(blue) size(0)) ///
    text(1.9 .58 "Treated units", placement(e) color(red) size(0)) ///
    title("Panel C) `mylabel1' ",size(2)) ///
    legend(label(1 "Treated units") label(2 "Control units") col(2) pos(6)) ///
    ylabel(, labsize(small) nogrid) xlabel(, labsize(small) nogrid) ytitle("Frequency") ///
    xtitle("Estimated probability of treatment") plotregion(lpattern(blank)) scheme(s1color) ///
    legend(on)
gr rename g1 , replace
* graph export "$figures/figuredesnsite3.pdf", replace
sleep 1000

cap drop _pscore
xtcloglog treat_light_prdm $psvar ,pa nolog i(cid)
predict _pscore
twoway (kdensity _pscore if treat_light_prdm==1, lpattern(dash) color(red) lwidth(medthick)) ///
    (kdensity _pscore if treat_light_prdm==0, color(blue) lwidth(thick)), ///
    text(10 .016 "Control units", placement(e) color(blue) size(0)) ///
    text(1.9 .58 "Treated units", placement(e) color(red) size(0)) ///
    title("Panel D) `mylabel2' ",size(2)) ///
    legend(label(1 "Treated units") label(2 "Control units") col(2) pos(6)) ///
    ylabel(, labsize(small) nogrid) xlabel(, labsize(small) nogrid) ytitle("Frequency") ///
    xtitle("Estimated probability of treatment") plotregion(lpattern(blank)) scheme(s1color) ///
    legend(on)
gr rename g2 , replace
* graph export "$figures/figuredensite4.pdf", replace

* set scheme s1color
grc1leg g1 g2, col(2) plotregion(fcolor(white)) plotregion(fcolor(white)) ///
    title("B. Overlap check: empirical distributions of the treatment propensity score",size(small))
* gr combine f1 f2, ycommon title("") graphregion(fcolor(white))
graph rename gb,replace
* graph export "$figures/figure_densities.pdf", replace

gr combine gtreat_labor1 gtreat_prdm1 g1 g2, col(2) plotregion(fcolor(white)) ///
    plotregion(fcolor(white))
* gr combine f1 f2, ycommon title("") graphregion(fcolor(white))
graph rename gc,replace
graph export "$figures/figure6.pdf", replace
graph export "$figures/figure6.png", replace
restore

* --- Balance table: Table B2 ---
preserve
estimates clear
eststo m1: xtcloglog $shock1 $covar l$yvar1,pa tolerance(1) i(cid)
capture drop ps1
capture drop ipw1
predict double ps1,mu
gen ipw1 = 1 if $shock1==1
replace ipw1 = ps1/(1-ps1) if $shock1==0

eststo m2: xtcloglog $shock2 $covar l$yvar1,pa tolerance(1) i(cid)
capture drop ps2
capture drop ipw2
predict double ps2,mu
gen ipw2 = 1 if $shock2==1
replace ipw2 = ps2/(1-ps2) if $shock2==0

esttab m*, replace se nodepvars nonotes se(3) b(3) sfmt(a3) stats(N N_g) nodepvars ///
    star(* 0.10 ** 0.05 *** 0.01)

esttab m* using "$tables/tableB2.csv", replace se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    stats(N N_g, label("Observations" "Number of countries")) nodepvars ///
    star(* 0.10 ** 0.05 *** 0.01)
esttab m* using "$tables/tableB2.tex", replace se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    stats(N N_g, label("Observations" "Number of countries")) nodepvars ///
    star(* 0.10 ** 0.05 *** 0.01)

balancetable $shock1 $covar using "$tables/somefile1a.xlsx", replace
balancetable $shock1 $covar using "$tables/somefile1b.xlsx" [aweight=ipw1], replace

balancetable $shock2 $covar using "$tables/somefile2a.xlsx", replace
balancetable $shock2 $covar using "$tables/somefile2b.xlsx" [aweight=ipw2], replace

tabstat $covar , by($shock1) s(mean) nototal
tabstat $covar [aweight=ipw1], by($shock1) s(mean) nototal

tabstat $covar , by($shock2) s(mean) nototal
tabstat $covar [aweight=ipw2], by($shock2) s(mean) nototal
restore
