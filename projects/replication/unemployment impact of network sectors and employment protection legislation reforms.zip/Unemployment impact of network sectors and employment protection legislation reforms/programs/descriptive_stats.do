*==============================================================================
* descriptive stats
*==============================================================================

clear all
set matsize 11000,permanently
set mem 1000m
set more off

* inputs
global homedir "/Users/kwamivigomado/Downloads/Unemployment impact of network sectors and employment protection legislation reforms"
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

* Import datasets
use "$datasets/MAIN_DATASETS.dta",clear

xtset cid year
sort cid year

* Control variable
global covar "lpwt_hci linflation_imf any_election yrcurnt crisis_dummy IMF55  polity2_jorra lwdi_trade lgini lgdp_growth_jorra labor_market product_market"

* Reform variable (Change vs episodes or shock)
global reform1 "labor_market_reform"
global reform2 "product_market_reform"

global shock1 "ftreat_light_labor"
global shock2 "ftreat_light_prdm"

* Dependent variable
global yvar1 "wdi_unempilo"

*------------------------------------------------------------------------------
* Table 2
*------------------------------------------------------------------------------

sutex $reform1 $reform2 $yvar1 $covar, lab nobs key(descstat) replace file(descstat.tex) ///
    title("Summary statistics") ///
    minmax

*------------------------------------------------------------------------------
* Figure 1: panel a
*------------------------------------------------------------------------------

preserve
collapse (mean) prdm_elec prdm_tel, by(year)
egen prdm_all=rmax(prdm_elec prdm_tel)

* Product market
label var prdm_all "Reforms in network sector market – Overall"
label var prdm_tel "Reforms in telecommunications market"
label var prdm_elec "Reforms in electricity market"
twoway ///
    (bar prdm_elec year, barwidth(1) legend(label(1 "Reforms in electricity market") size(vsmall))) ///
    || ///
    (rbar prdm_elec prdm_tel year, barwidth(1) legend(label(2 "Reforms in telecommunications market") size(vsmall))) ///
    || ///
    (line prdm_all year, lcolor(blue) lwidth(thick) legend(label(3 "Reforms in network sector market – overall") size(vsmall))) ///
    , legend(cols(2) pos(6)) ylab(, nogrid) ///
    subtitle("Panel A: Reforms in network sector market – overall", size(small)) ///
    xlab(, nogrid angle(45)) ///
    xlabel(1990(2)2014)

gr rename g1, replace

restore

*------------------------------------------------------------------------------
* Figure 1: panel b
*------------------------------------------------------------------------------

preserve
collapse (mean) labor_vg labor_pi labor_fc labor_rm labor_cd, by(year)
egen labor=rmax(labor_vg labor_pi labor_fc labor_rm labor_cd)

label var labor "Labor market institutions reforms - Overall"
label var labor_vg "Valid grounds"
label var labor_pi "Procedural inconvenience"
label var labor_fc "Firing costs"
label var labor_rm "Redress measures"
label var labor_cd "Additional requirements for collective dismissal"
twoway (bar labor_rm year, barwidth(1)) || ///
    (rbar labor_rm labor_vg year, barwidth(1) legend(label(2 "Valid grounds") size(vsmall))) || ///
    (rbar labor_vg labor_pi year, barwidth(1) legend(label(3 "Firing costs") size(vsmall))) || ///
    (rbar labor_pi labor_fc year, barwidth(1) legend(label(4 "Procedural inconvenience") size(vsmall))) ///
    || ///
    (rbar labor_fc labor_cd year, barwidth(1) legend(label(5 "Additional requirements " "for collective dismissal") size(vsmall))) ///
    || ///
    (line labor year, lcolor(blue) lpattern(dash) lwidth(thick) legend(label(6 "Employment protection legislation reforms - Overall") size(vsmall))), ///
    legend(cols(2) pos(6)) ylab(, nogrid) ///
    subtitle("Panel B: Employment protection legislation reforms", size(small)) ///
    xlab(, nogrid angle(45)) ///
    xlabel(1990(2)2014)

gr rename g3, replace

restore

graph combine g1 g3,cols(2) title("") graphregion(fcolor(white))
graph rename ga,replace
graph export "$figures/figure1.png", replace
graph export "$figures/figure1.pdf", replace

*------------------------------------------------------------------------------
* Figure 3
*------------------------------------------------------------------------------

* --- Change ---
preserve
foreach foodGroup in BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE {
    // Create individual graphs using a loop
    if "`foodGroup'" == "BFA"  local graphTitle "Burkina Faso "
    if "`foodGroup'" == "CIV"  local graphTitle "Cote d'Ivoire"
    if "`foodGroup'" == "CMR"  local graphTitle "Cameroon"
    if "`foodGroup'" == "DZA"  local graphTitle "Algeria"
    if "`foodGroup'" == "EGY"  local graphTitle "Egypt"
    if "`foodGroup'" == "ETH"  local graphTitle " Ethiopia"
    if "`foodGroup'" == "GHA"  local graphTitle " Ghana"

    if "`foodGroup'" == "KEN"  local graphTitle "Kenya"
    if "`foodGroup'" == "MAR"  local graphTitle "Morocco"
    if "`foodGroup'" == "MDG"  local graphTitle "Madagascar"
    if "`foodGroup'" == "MOZ"  local graphTitle "Mozambique"
    if "`foodGroup'" == "NGA"  local graphTitle "Nigeria"
    if "`foodGroup'" == "SEN"  local graphTitle "Senegal"

    if "`foodGroup'" == "TUN"  local graphTitle " Tunisia"
    if "`foodGroup'" == "TZA"  local graphTitle "Tanzania"
    if "`foodGroup'" == "UGA"  local graphTitle "Uganda"
    if "`foodGroup'" == "ZAF"  local graphTitle "South Africa"
    if "`foodGroup'" == "ZWE"  local graphTitle " Zimbabwe"

    twoway bar wdi_unempilo year if ccode=="`foodGroup'", yaxis(1) ///
        ytitle("Avg. Unemployment, total" "(% of total labor force)", axis(1) size(vsmall)) ///
        barwidth(.9) fintensity(inten0) lcolor(black) ///
        xlab(1990 1995 2000 2005 2010 2014,angle(45) nogrid) ylabel(, axis(1) nogrid) || line ///
        $reform2 $reform1 year if ccode=="`foodGroup'", yaxis(2) ///
        ytitle("Average reforms in network" "sector or employment protection" "legislation market institutions", axis(2) size(vsmall)) ///
        ylabel(, axis(2) nogrid) xlab(1990 1995 2000 2005 2010 2014,angle(45) nogrid) ///
        lwidth(thick thick) title("`graphTitle'") xtitle("Year") graphregion(color(white)) ///
        bgcolor(white) ///
        legend( order(1 "Unemployment, total (% of total labor force)" 2 "Reforms (change) in network sector market institutions- Overall" 3 "Reforms (change) in employment protection legislation institutions- Overall") cols(2) pos(6) size(vsmall)) ///
        name("`foodGroup'",replace)

}

grc1leg BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE, cols(4) ///
    title("", justification(center) color(black) span pos(17)) graphregion( color(white)) ///
    plotregion(color(white))

gr rename g5 , replace
graph export "$figures/figure3.pdf", replace
graph export "$figures/figure3.png", replace
restore

*------------------------------------------------------------------------------
* Figure 4
*------------------------------------------------------------------------------

graph bar (sum) treat_light_labor treat_light_prdm, over(year,lab(angle(90))) bargap(-30) ///
    legend( label(1 "EPL reforms episodes") label(2 "Network sector reforms episodes") span pos(6) rows(1)) ///
    ylab(,nogrid) subtitle("Panel A) Reforms episodes by year",size(2)) ///
    ytitle("# episodes")
gr rename f1 , replace
graph export "$figures/figepisodes.pdf", replace

graph bar (sum) treat_light_labor treat_light_prdm, over(country,lab(angle(45))) bargap(-30) ///
    legend( label(1 "EPL reforms episodes") label(2 "Network sector reforms episodes") span pos(6) rows(1)) ///
    ylab(,nogrid) subtitle("Panel B) Reforms episodes by country",size(2)) ///
    ytitle("# episodes")
gr rename f2 , replace
graph export "$figures/figepisodescountries.pdf", replace

grc1leg f1 f2, cols(2) ycommon title("", justification(center) color(black) span pos(17)) ///
    graphregion( color(white)) ///
    plotregion(color(white))
gr rename f3 , replace
graph export "$figures/figure4.pdf", replace
graph export "$figures/figure4.png", replace

*------------------------------------------------------------------------------
* Appendix graph
*------------------------------------------------------------------------------

* --- Level ---
preserve
foreach foodGroup in BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE {
    // Create individual graphs using a loop
    if "`foodGroup'" == "BFA"  local graphTitle "Burkina Faso "
    if "`foodGroup'" == "CIV"  local graphTitle "Cote d'Ivoire"
    if "`foodGroup'" == "CMR"  local graphTitle "Cameroon"
    if "`foodGroup'" == "DZA"  local graphTitle "Algeria"
    if "`foodGroup'" == "EGY"  local graphTitle "Egypt"
    if "`foodGroup'" == "ETH"  local graphTitle " Ethiopia"
    if "`foodGroup'" == "GHA"  local graphTitle " Ghana"

    if "`foodGroup'" == "KEN"  local graphTitle "Kenya"
    if "`foodGroup'" == "MAR"  local graphTitle "Morocco"
    if "`foodGroup'" == "MDG"  local graphTitle "Madagascar"
    if "`foodGroup'" == "MOZ"  local graphTitle "Mozambique"
    if "`foodGroup'" == "NGA"  local graphTitle "Nigeria"
    if "`foodGroup'" == "SEN"  local graphTitle "Senegal"

    if "`foodGroup'" == "TUN"  local graphTitle " Tunisia"
    if "`foodGroup'" == "TZA"  local graphTitle "Tanzania"
    if "`foodGroup'" == "UGA"  local graphTitle "Uganda"
    if "`foodGroup'" == "ZAF"  local graphTitle "South Africa"
    if "`foodGroup'" == "ZWE"  local graphTitle " Zimbabwe"

    twoway bar wdi_unempilo year if ccode=="`foodGroup'", yaxis(1) ///
        ytitle("Avg. Unemployment, total" "(% of total labor force)", axis(1) size(vsmall)) ///
        barwidth(.9) fintensity(inten0) lcolor(black) ///
        xlab(1990 1995 2000 2005 2010 2014,angle(45) nogrid) ylabel(, axis(1) nogrid) || line ///
        prdm labor year if ccode=="`foodGroup'", yaxis(2) ///
        ytitle("Avg. Network sector or" "employemnet protection legislation" "market institutions", axis(2) size(vsmall)) ///
        ylabel(, axis(2) nogrid) xlab(1990 1995 2000 2005 2010 2014,angle(45) nogrid) ///
        lwidth(thick thick) title("`graphTitle'") xtitle("Year") graphregion(color(white)) ///
        bgcolor(white) ///
        legend( order(1 "Unemployment, total (% of total labor force)" 2 "Network sector market institutions- Overall" 3 "Employment protection legislation institutions- Overall") cols(2) pos(6)) ///
        name("`foodGroup'",replace)

}

grc1leg BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE, cols(5) ///
    title("", justification(center) color(black) span pos(17)) graphregion( color(white)) ///
    plotregion(color(white))

gr rename g4 , replace
graph export "$figures/figureA1.pdf", replace
graph export "$figures/figureA1.png", replace

restore
