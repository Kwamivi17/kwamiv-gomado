*==============================================================================
* Fig14
*==============================================================================

clear all
set matsize 11000,permanently
set mem 1000m
set more off

* inputs
global homedir "/Users/kwamivigomado/Downloads/Unemployment impact of network sectors and employment protection legislation reforms"
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

* Import datasets
use "$datasets/MAIN_DATASETS.dta",clear

xtset cid year
sort cid year

* Control variable
global covar "lpwt_hci linflation_imf any_election yrcurnt crisis_dummy IMF55  polity2_jorra lwdi_trade lgini lgdp_growth_jorra labor_market product_market"

* Reform variable (Change vs episodes or shock)
global reform1 "labor_market_reform"
global reform2 "product_market_reform"

global shock1 "ftreat_light_labor"
global shock2 "ftreat_light_prdm"

* Dependent variable
global yvar1 "wdi_unempilo"

* Horizon
global min 0
global max 5

* Colors
global bcolor1 blue
global bcolor2 red
global iccolor black

* --- Local projection method: AIPW ---
foreach v in MIMIC_p wdi_fdiin tfp ctfp Grossfixedcapitalformation{
    forvalues i=0/5{
        cap drop `v'`i'
        gen `v'`i'=(f`i'.`v'-l.`v')/l.`v'
        cap drop log`v'
        cap drop log`v'`i'
        gen log`v'=log(`v'+1)
        gen log`v'`i'=(f`i'.log`v'-l.log`v')
    }
}

label var MIMIC_p "MIMIC"
label var wdi_fdiin "FDI"
label var Grossfixedcapitalformation "GFCF"
label var ctfp "TFP"

local mylabel1 : variable label $shock1
local mylabel2 : variable label $shock2

preserve
foreach treat in $shock1{
    foreach v in MIMIC_p wdi_fdiin Grossfixedcapitalformation ctfp{
        * local mylabel1 : variable label `v'
        * Visualization
        if "`v'"=="MIMIC_p"{
            local panel = "A"
            local title = "MIMIC"
        }

        if "`v'"=="wdi_fdiin"{
            local panel = "B"
            local title = "FDI"
        }

        if "`v'"=="Grossfixedcapitalformation"{
            local panel = "C"
            local title = "GFCF"
        }

        if "`v'"=="ctfp"{
            local panel = "D"
            local title = "TFP"
        }
        pause on
        capture drop pihat pihat0
        * make variables
        cap drop b u d Years Zero u10 d10
        gen Years = _n-2 if _n<=7
        gen Zero = 0 if _n<=7
        gen b=0
        gen u=0
        gen d=0
        gen u10=0
        gen d10=0

        * basic probit
        * xi: probit ftreatment debtgdp hply dly ldly treatment if year>=1980 & year<=2007
        * saturated probit
        qui xtcloglog `treat' $covar lwdi_unempilo,pa tolerance(1) i(cid)
        * raw prscore, not truncated (pihat0)
        predict pihat0,mu

        * truncate ipws at 10 (pihat)
        gen pihat=pihat0
        * replace pihat = .9 if pihat>.9 & pihat~=.
        * replace pihat = .1 if pihat<.1 & pihat~=.

        * sort again
        sort cid year
        xtset cid year

        * DR - IPWRA - ATE weighted by IPWT (Davidian/Lunt) WITH COMMON SLOPE/CFEs (beta1=beta0)
        * no truncations (use phat0)
        local mylabel : variable label `treat'
        capture drop a invwt
        gen a=`treat' // define treatment indicator as a from Lunt et al.
        gen invwt=a/pihat + (1-a)/(1-pihat) // invwt from Lunt et al.
        qui forvalues h=$min/$max {
            * SAME OUTCOME REG IN BOTH T&C THIS TIME, REST ALL THE SAME
            /*qui*/ eststo: xtscc log`v'`h' `treat' $covar i.year [aweight=invwt], ase fe ///
                lag(`=`h' + 1')
            gen samp=e(sample) // set sample
            predict mu0 if samp==1 & `treat'==0 // actual
            predict mu1 if samp==1 & `treat'==1 // actual
            replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1 // ghost
            replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0 // ghost
            * from Lunt et al
            generate mdiff1=(-(a-pihat)*mu1/pihat)-((a-pihat)*mu0/(1-pihat))
            generate iptw=(2*a-1)*log`v'`h'*invwt
            generate dr1=iptw+mdiff1
            qui gen ATE_IPWRA=1 // constant for convenience in next reg to get mean
            reg dr1 ATE_IPWRA, nocons
            eststo `v'`h'
            sum dr1
            local dr1m = r(mean)
            gen Isq = (dr1-`dr1m')^2
            sum Isq
            estadd scalar RobustSE = sqrt(r(mean)/r(N))
            estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
            capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
            capture scalar drop dr1m
            * store for charts
            replace b = _b[ATE_IPWRA] if _n == `h'+2
            replace u = _b[ATE_IPWRA] + 1.96* _se[ATE_IPWRA] if _n == `h'+2
            replace d = _b[ATE_IPWRA] - 1.96* _se[ATE_IPWRA] if _n == `h'+2
            replace u10 = _b[ATE_IPWRA] + 1.64* _se[ATE_IPWRA] if _n == `h'+2
            replace d10 = _b[ATE_IPWRA] - 1.64* _se[ATE_IPWRA] if _n == `h'+2
        }
        * charts

        twoway (rarea u d Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
            (rarea u10 d10 Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
            (line b Years,lcolor(purple) lpattern(solid) lwidth(thick)) ///
            (line Zero Years, lcolor(black)), ///
            legend(order(3 "ATE: `mylabel1'") cols(2) pos(6) size(tiny)) ///
            subtitle("{bf}Panel `panel': `title' ", color(black) size(vsmall)) ///
            ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
            graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
            xlab(-1(1)5, nogrid)
        gr rename `panel' , replace
    }

}
restore

preserve
qui gen ATE_IPWRA=1 // constant for convenience in next reg to get mean
capture erase "$tables/tableB3.csv"
capture erase "$tables/tableB3.tex"

label var ATE_IPWRA "ATE u wts: `mylabel1'"
esttab MIMIC_p*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab wdi_fdiin*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab Grossfixedcapitalformation*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
    sfmt(a3) nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab ctfp*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label ///
    varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab MIMIC_p* using "$tables/tableB3.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep(ATE_IPWRA)

esttab wdi_fdiin* using "$tables/tableB3.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep(ATE_IPWRA)

esttab Grossfixedcapitalformation* using "$tables/tableB3.tex", append se keep(ATE_IPWRA) ///
    nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label varlabels(_cons Constant) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab ctfp* using "$tables/tableB3.tex", append se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
    sfmt(a3) nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
restore

* --- Product market ---
preserve
foreach treat in $shock2{
    foreach v in MIMIC_p wdi_fdiin Grossfixedcapitalformation ctfp{
        * Visualization
        if "`v'"=="MIMIC_p"{
            local panel = "E"
            local title = "MIMIC"
        }

        if "`v'"=="wdi_fdiin"{
            local panel = "F"
            local title = "FDI"
        }

        if "`v'"=="Grossfixedcapitalformation"{
            local panel = "G"
            local title = "GFCF"
        }

        if "`v'"=="ctfp"{
            local panel = "H"
            local title = "TFP"
        }
        pause on
        capture drop pihat pihat0
        * make variables
        cap drop b u d Years Zero u10 d10
        gen Years = _n-2 if _n<=7
        gen Zero = 0 if _n<=7
        gen b=0
        gen u=0
        gen d=0
        gen u10=0
        gen d10=0

        * basic probit
        * xi: probit ftreatment debtgdp hply dly ldly treatment if year>=1980 & year<=2007
        * saturated probit
        qui xtcloglog `treat' $covar lwdi_unempilo,pa tolerance(1) i(cid)
        * raw prscore, not truncated (pihat0)
        predict pihat0,mu

        * truncate ipws at 10 (pihat)
        gen pihat=pihat0
        * replace pihat = .9 if pihat>.9 & pihat~=.
        * replace pihat = .1 if pihat<.1 & pihat~=.

        * sort again
        sort cid year
        xtset cid year

        * DR - IPWRA - ATE weighted by IPWT (Davidian/Lunt) WITH COMMON SLOPE/CFEs (beta1=beta0)
        * no truncations (use phat0)
        local mylabel : variable label `treat'
        capture drop a invwt
        gen a=`treat' // define treatment indicator as a from Lunt et al.
        gen invwt=a/pihat + (1-a)/(1-pihat) // invwt from Lunt et al.
        qui forvalues h=$min/$max {
            * SAME OUTCOME REG IN BOTH T&C THIS TIME, REST ALL THE SAME
            qui eststo: xtscc log`v'`h' `treat' $covar i.year [aweight=invwt], ase fe ///
                lag(`=`h' + 1')
            gen samp=e(sample) // set sample
            predict mu0 if samp==1 & `treat'==0 // actual
            predict mu1 if samp==1 & `treat'==1 // actual
            replace mu0 = mu1 - _b[`treat'] if samp==1 & `treat'==1 // ghost
            replace mu1 = mu0 + _b[`treat'] if samp==1 & `treat'==0 // ghost
            * from Lunt et al
            generate mdiff1=(-(a-pihat)*mu1/pihat)-((a-pihat)*mu0/(1-pihat))
            generate iptw=(2*a-1)*log`v'`h'*invwt
            generate dr1=iptw+mdiff1
            qui gen ATE_IPWRA=1 // constant for convenience in next reg to get mean
            reg dr1 ATE_IPWRA, nocons cluste(cid)
            eststo `v'`h'
            sum dr1
            local dr1m = r(mean)
            gen Isq = (dr1-`dr1m')^2
            sum Isq
            estadd scalar RobustSE = sqrt(r(mean)/r(N))
            estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
            capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
            capture scalar drop dr1m
            * store for charts
            replace b = _b[ATE_IPWRA] if _n == `h'+2
            replace u = _b[ATE_IPWRA] + 1.96* _se[ATE_IPWRA] if _n == `h'+2
            replace d = _b[ATE_IPWRA] - 1.96* _se[ATE_IPWRA] if _n == `h'+2
            replace u10 = _b[ATE_IPWRA] + 1.64* _se[ATE_IPWRA] if _n == `h'+2
            replace d10 = _b[ATE_IPWRA] - 1.64* _se[ATE_IPWRA] if _n == `h'+2
        }
        * charts

        twoway (rarea u d Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
            (rarea u10 d10 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
            (line b Years,lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
            (line Zero Years, lcolor(black)), ///
            legend(order(3 "ATE: `mylabel2'") cols(2) pos(6) size(tiny)) ///
            subtitle("{bf}Panel `panel': `title' ", color(black) size(vsmall)) ///
            ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
            graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
            xlab(-1(1)5, nogrid)
        gr rename `panel' , replace
    }
}
restore

preserve
* MIMIC_p wdi_fdiin Grossfixedcapitalformation ctfp
qui gen ATE_IPWRA=1 // constant for convenience in next reg to get mean
* capture  erase "$tables/tableB3.csv"
* capture  erase "$tables/tableB3.tex"

label var ATE_IPWRA "ATE u wts: `mylabel2'"
esttab MIMIC_p*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab wdi_fdiin*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars ///
    label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab Grossfixedcapitalformation*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
    sfmt(a3) nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
esttab ctfp*, replace se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label ///
    varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab MIMIC_p* using "$tables/tableB3.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep(ATE_IPWRA)

esttab wdi_fdiin* using "$tables/tableB3.tex", append se nodepvars nonotes se(3) b(3) sfmt(a3) ///
    nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square")) ///
    keep(ATE_IPWRA)

esttab Grossfixedcapitalformation* using "$tables/tableB3.tex", append se keep(ATE_IPWRA) ///
    nodepvars nonotes se(3) b(3) sfmt(a3) nodepvars label varlabels(_cons Constant) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))

esttab ctfp* using "$tables/tableB3.tex", append se keep(ATE_IPWRA) nodepvars nonotes se(3) b(3) ///
    sfmt(a3) nodepvars label varlabels(_cons Constant) star(* 0.10 ** 0.05 *** 0.01) ///
    stats( N r2_w, label("Observations" "Within R-square"))
restore

* Now combining the plots together
graph combine A B C D E F G H, cols(4) graphregion(fcolor(white)) note("")
gr rename g4 , replace
graph export "$figures/figure14.pdf", replace
graph export "$figures/figure14.png", replace
