*==============================================================================
* Fig11
*==============================================================================

clear all
set matsize 11000,permanently
set mem 1000m
set more off

* inputs
global homedir "/Users/kwamivigomado/Downloads/Unemployment impact of network sectors and employment protection legislation reforms"
global logdir "$homedir/log/log files"
global datasets "$homedir/datasets"
global tables "$homedir/tables"
global figures "$homedir/figures"
set scheme white_tableau

* Import datasets
use "$datasets/MAIN_DATASETS.dta",clear

xtset cid year
sort cid year

* Control variable
global covar "lpwt_hci linflation_imf any_election yrcurnt crisis_dummy IMF55  polity2_jorra lwdi_trade lgini lgdp_growth_jorra labor_market product_market"

* Reform variable (Change vs episodes or shock)
global reform1 "labor_market_reform"
global reform2 "product_market_reform"

global shock1 "ftreat_light_labor"
global shock2 "ftreat_light_prdm"

* Dependent variable
global yvar1 "wdi_unempilo"

* Horizon
global min 0
global max 5

* Colors
global bcolor1 blue
global bcolor2 red
global iccolor black

* --- Exclude country ---

local mylabel1 : variable label $shock1
local mylabel2 : variable label $shock2

* --- Product market ---
preserve
pause on
capture drop pihat pihat0
* make variables
cap drop b u d Years Zero u10 d10
cap drop b1 u1 d1 u101 d101
gen Years = _n-2 if _n<=7
gen Zero = 0 if _n<=7
gen b=0
gen u=0
gen d=0
gen u10=0
gen d10=0

gen b1=0
gen u1=0
gen d1=0
gen u101=0
gen d101=0

* basic probit
* xi: probit ftreatment debtgdp hply dly ldly treatment if year>=1980 & year<=2007
* saturated probit
xtcloglog $shock1 $covar l$yvar1,pa tolerance(1) i(cid)
* raw prscore, not truncated (pihat0)
predict pihat0,mu

* truncate ipws at 10 (pihat)
gen pihat=pihat0
* replace pihat = .9 if pihat>.9 & pihat~=.
* replace pihat = .1 if pihat<.1 & pihat~=.

* saturated probit
xtcloglog $shock2 $covar l$yvar1,pa tolerance(1) i(cid)
* raw prscore, not truncated (pihat0)
predict pihat2,mu

* truncate ipws at 10 (pihat)
gen pihat1=pihat2
* replace pihat = .9 if pihat>.9 & pihat~=.
* replace pihat = .1 if pihat<.1 & pihat~=.

* sort again
sort cid year
xtset cid year

* DR - IPWRA - ATE weighted by IPWT (Davidian/Lunt) WITH COMMON SLOPE/CFEs (beta1=beta0)
* no truncations (use phat0)
foreach foodGroup in BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE {
    // Create individual graphs using a loop
    if "`foodGroup'" == "BFA"  local graphTitle "Burkina Faso "
    if "`foodGroup'" == "CIV"  local graphTitle "Cote d'Ivoire"
    if "`foodGroup'" == "CMR"  local graphTitle "Cameroon"
    if "`foodGroup'" == "DZA"  local graphTitle "Algeria"
    if "`foodGroup'" == "EGY"  local graphTitle "Egypt"
    if "`foodGroup'" == "ETH"  local graphTitle " Ethiopia"
    if "`foodGroup'" == "GHA"  local graphTitle " Ghana"

    if "`foodGroup'" == "KEN"  local graphTitle "Kenya"
    if "`foodGroup'" == "MAR"  local graphTitle "Morocco"
    if "`foodGroup'" == "MDG"  local graphTitle "Madagascar"
    if "`foodGroup'" == "MOZ"  local graphTitle "Mozambique"
    if "`foodGroup'" == "NGA"  local graphTitle "Nigeria"
    if "`foodGroup'" == "SEN"  local graphTitle "Senegal"

    if "`foodGroup'" == "TUN"  local graphTitle " Tunisia"
    if "`foodGroup'" == "TZA"  local graphTitle "Tanzania"
    if "`foodGroup'" == "UGA"  local graphTitle "Uganda"
    if "`foodGroup'" == "ZAF"  local graphTitle "South Africa"
    if "`foodGroup'" == "ZWE"  local graphTitle " Zimbabwe"

    local mylabel : variable label $shock1
    capture drop a invwt
    gen a=$shock1 // define treatment indicator as a from Lunt et al.
    gen invwt=a/pihat + (1-a)/(1-pihat) // invwt from Lunt et al.

    * local mylabel : variable label $shock2
    capture drop a1 invwt1
    gen a1=$shock2 // define treatment indicator as a from Lunt et al.
    gen invwt1=a1/pihat1 + (1-a1)/(1-pihat1) // invwt from Lunt et al.

    forvalues h=$min/$max {
        * SAME OUTCOME REG IN BOTH T&C THIS TIME, REST ALL THE SAME
        qui eststo: xtscc $yvar1`h' $shock1 $covar i.year [aweight=invwt] if ///
            ccode!="`foodGroup'", ase fe ///
            lag(`=`h' + 1')
        gen samp=e(sample) // set sample
        predict mu0 if samp==1 & $shock1==0 // actual
        predict mu1 if samp==1 & $shock1==1 // actual
        replace mu0 = mu1 - _b[$shock1] if samp==1 & $shock1==1 // ghost
        replace mu1 = mu0 + _b[$shock1] if samp==1 & $shock1==0 // ghost
        * from Lunt et al
        generate mdiff1=(-(a-pihat)*mu1/pihat)-((a-pihat)*mu0/(1-pihat))
        generate iptw=(2*a-1)*$yvar1`h'*invwt
        generate dr1=iptw+mdiff1
        qui gen ATE_IPWRA=1 // constant for convenience in next reg to get mean
        reg dr1 ATE_IPWRA, nocons
        eststo $shock1`i'
        sum dr1
        local dr1m = r(mean)
        gen Isq = (dr1-`dr1m')^2
        sum Isq
        estadd scalar RobustSE = sqrt(r(mean)/r(N))
        estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
        capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA*
        capture scalar drop dr1m
        * store for charts
        replace b = _b[ATE_IPWRA] if _n == `h'+2
        replace u = _b[ATE_IPWRA] + 1.96* _se[ATE_IPWRA] if _n == `h'+2
        replace d = _b[ATE_IPWRA] - 1.96* _se[ATE_IPWRA] if _n == `h'+2
        replace u10 = _b[ATE_IPWRA] + 1.64* _se[ATE_IPWRA] if _n == `h'+2
        replace d10 = _b[ATE_IPWRA] - 1.64* _se[ATE_IPWRA] if _n == `h'+2

        * SAME OUTCOME REG IN BOTH T&C THIS TIME, REST ALL THE SAME
        qui eststo: xtscc $yvar1`h' $shock2 $covar i.year [aweight=invwt1] if ///
            ccode!="`foodGroup'", ase fe ///
            lag(`=`h' + 1')
        gen samp1=e(sample) // set sample
        predict mu01 if samp1==1 & $shock2==0 // actual
        predict mu11 if samp1==1 & $shock2==1 // actual
        replace mu01 = mu11 - _b[$shock2] if samp1==1 & $shock2==1 // ghost
        replace mu11 = mu01 + _b[$shock2] if samp1==1 & $shock2==0 // ghost
        * from Lunt et al
        generate mdiff11=(-(a1-pihat1)*mu11/pihat1)-((a1-pihat1)*mu01/(1-pihat1))
        generate iptw1=(2*a1-1)*$yvar1`h'*invwt1
        generate dr11=iptw+mdiff11
        qui gen ATE_IPWRA1=1 // constant for convenience in next reg to get mean
        reg dr11 ATE_IPWRA1, nocons
        eststo $shock2`h'
        sum dr11
        local dr1m = r(mean)
        gen Isq1 = (dr1-`dr1m')^2
        sum Isq1
        estadd scalar RobustSE = sqrt(r(mean)/r(N))
        estadd scalar pvalue = normal(`dr1m'/sqrt(r(mean)/r(N)))
        capture drop iptw Isq mdiff1 dr1 mu1 mu0 samp ATE_IPWRA1*
        capture scalar drop dr1m
        * store for charts
        replace b1 = _b[ATE_IPWRA1] if _n == `h'+2
        replace u1 = _b[ATE_IPWRA1] + 1.96* _se[ATE_IPWRA1] if _n == `h'+2
        replace d1 = _b[ATE_IPWRA1] - 1.96* _se[ATE_IPWRA1] if _n == `h'+2
        replace u101 = _b[ATE_IPWRA1] + 1.64* _se[ATE_IPWRA1] if _n == `h'+2
        replace d101 = _b[ATE_IPWRA1] - 1.64* _se[ATE_IPWRA1] if _n == `h'+2
    }
    * charts

    twoway (rarea u d Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u1 d1 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u10 d10 Years,fcolor(purple%15) lcolor(gs13) lpattern(solid)) ///
        (rarea u101 d101 Years,fcolor(blue%15) lcolor(gs13) lpattern(solid)) ///
        (line b Years,lcolor(purple%50) lpattern(solid) lwidth(thick)) ///
        (line b1 Years,lcolor(blue%50) lpattern(solid) lwidth(thick)) ///
        (line Zero Years, lcolor(black)), ///
        legend(order( 5 "ATE: `mylabel1'" 6 "ATE: `mylabel2'") cols(2) pos(6) size(vsmall)) ///
        subtitle("Excluded country: `graphTitle'", color(black) size(vsmall)) ///
        ytitle("Percent", size(medsmall)) xtitle("Year", size(medsmall)) ///
        graphregion(color(white)) plotregion(color(white)) ylab(, nogrid) ///
        xlab(-1(1)5, nogrid)
    gr rename `foodGroup' , replace
}

grc1leg BFA CIV CMR DZA EGY ETH GHA KEN MAR MDG MOZ NGA SEN TUN TZA UGA ZAF ZWE, cols(5) ///
    title("", justification(center) color(black) span pos(17)) graphregion( color(white)) ///
    plotregion(color(white))

gr rename g4 , replace
graph export "$figures/figure11.pdf", replace
graph export "$figures/figure11.png", replace
restore
